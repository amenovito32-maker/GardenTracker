package dev.vito.gardentracker;

import java.util.Locale;

/** Goal tracker: shows progress and an ETA at your current session rate. */
public final class Goals {
	private Goals() {}

	/** HUD value for the selected goal, or null if there is none. */
	public static String value(Config c) {
		return switch (c.goalType) {
			case NONE -> null;
			case CULTIVATING -> cultivating();
			case LEVEL -> level();
			case COINS -> coins(c.goalCoins);
		};
	}

	private static String cultivating() {
		long counter = Session.toolCounter;
		if (counter < 0) return "§8hold your farming tool";
		int tier = Session.cultivatingTier(counter);
		if (tier >= Session.CULTIVATING_TIERS.length) return "§aCultivating X!";
		long target = Session.CULTIVATING_TIERS[tier];
		long remaining = target - counter;
		return "Cultivating " + Text.roman(tier + 1) + " §8- §f" + Text.shortNum(remaining) + " left" + eta(remaining, Session.cultivatingPerHour());
	}

	private static String level() {
		if (Session.xpNeeded > 0 && Session.xpCurrent >= 0) {
			double remaining = Session.xpNeeded - Session.xpCurrent;
			return String.format(Locale.ROOT, "Next level §8- §f%.1f%%", Session.xpPercent) + eta(remaining, Session.xpPerHour());
		}
		if (Session.xpPercent >= 0) {
			return String.format(Locale.ROOT, "Next level §8- §f%.1f%%", Session.xpPercent);
		}
		return "Next level §8- farm to start";
	}

	private static String coins(long target) {
		double remaining = target - Session.coins;
		if (remaining <= 0) return "§a" + Text.shortNum(target) + " coins reached!";
		return Text.shortNum(target) + " coins §8- §f" + Text.shortNum(remaining) + " left" + eta(remaining, Session.coinsPerHour());
	}

	private static String eta(double remaining, double perHour) {
		if (perHour <= 0) return "";
		long seconds = (long) (remaining / perHour * 3600.0);
		return " §8| §e" + Text.time(seconds);
	}
}
