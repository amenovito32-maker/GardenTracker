package dev.vito.gardentracker;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Settings saved to config/gardentracker.json. Change them in the menu (/gt or the hotkey). */
public final class Config {
	public enum PriceMode { BEST, NPC, BAZAAR }
	public enum GoalType { NONE, CULTIVATING, LEVEL, COINS }

	// HUD
	public boolean hudEnabled = true;
	public int hudX = 4;
	public int hudY = 40;
	public float hudScale = 1.0f;
	public boolean hudBackground = true;
	public Theme theme = Theme.CLASSIC;
	public boolean compact = false;
	/** HudLine names that are hidden. */
	public List<String> hiddenLines = new ArrayList<>(List.of("LIVE_RATE", "PLOT_MAP"));
	/** HudLine names in display order (missing ones are added at the end). */
	public List<String> lineOrder = new ArrayList<>();
	/** Custom accent color (ARGB), 0 = use the theme's. */
	public int accentColor = 0;
	/** Background opacity in percent (0-100). */
	public int backgroundOpacity = 60;
	public boolean hudBorder = true;
	public boolean textShadow = true;
	public boolean showTitle = true;
	/** Show 1.23M (short) or 1,234,567 (full). */
	public boolean shortNumbers = true;
	/** Extra pixels between HUD lines. */
	public int lineSpacing = 1;

	// Rates
	public PriceMode priceMode = PriceMode.BEST;
	/** Seconds without farming before the session timer pauses. */
	public int pauseSeconds = 10;

	// Pest plots
	public boolean plotHighlight = true;
	public boolean plotHighlightThroughWalls = true;
	public boolean plotHighlightLabels = true;
	public boolean plotHighlightFill = false;
	public int plotHighlightColor = 0xFFFF5555;
	/** Height of the highlight box above the lowest Garden point, in blocks. */
	public int plotHighlightHeight = 12;

	// Alerts
	public boolean pestAlert = true;
	/** Alert once the number of alive pests reaches this. */
	public int pestAlertThreshold = 4;
	/** Ping when you stop farming for this many seconds (0 = off). */
	public int afkAlertSeconds = 15;
	public boolean visitorQueueAlert = true;
	public boolean alertSounds = true;

	// Visitors
	public boolean visitorCostTooltip = true;
	/** Your personal "fair" price for one copper. Offers cheaper than this are marked as good deals. */
	public int coinsPerCopper = 6000;

	// Session summary and history
	public boolean summaryOnLeave = true;
	public boolean saveHistory = true;

	// Goal tracker
	public GoalType goalType = GoalType.CULTIVATING;
	public long goalCoins = 10_000_000L;

	// Personal records (kept between game restarts)
	public double bestCoinsPerHour = 0;
	public double bestCultivatingPerHour = 0;
	public double bestXpPerHour = 0;

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("gardentracker.json");
	private static Config instance = new Config();

	public static Config get() {
		return instance;
	}

	public boolean isShown(HudLine line) {
		return !hiddenLines.contains(line.name());
	}

	public void setShown(HudLine line, boolean shown) {
		hiddenLines.remove(line.name());
		if (!shown) hiddenLines.add(line.name());
	}

	/** HUD lines in the user's order. */
	public List<HudLine> orderedLines() {
		List<HudLine> out = new ArrayList<>();
		for (String name : lineOrder) {
			for (HudLine l : HudLine.values()) if (l.name().equals(name) && !out.contains(l)) out.add(l);
		}
		for (HudLine l : HudLine.values()) if (!out.contains(l)) out.add(l);
		return out;
	}

	/** Moves a HUD line up (-1) or down (+1). */
	public void moveLine(HudLine line, int dir) {
		List<HudLine> order = orderedLines();
		int i = order.indexOf(line), j = i + dir;
		if (i < 0 || j < 0 || j >= order.size()) return;
		order.set(i, order.get(j));
		order.set(j, line);
		lineOrder = new ArrayList<>();
		for (HudLine l : order) lineOrder.add(l.name());
	}

	/** The accent color to use (custom or the theme's). */
	public int accent() {
		return accentColor != 0 ? accentColor : theme.accent;
	}

	public static void load() {
		try {
			if (Files.exists(FILE)) {
				try (Reader reader = Files.newBufferedReader(FILE)) {
					Config loaded = GSON.fromJson(reader, Config.class);
					if (loaded != null) instance = loaded;
				}
			}
		} catch (Exception e) {
			GardenTracker.LOGGER.warn("Could not read gardentracker.json, using defaults", e);
		}
		// Fill anything missing from older config files.
		if (instance.priceMode == null) instance.priceMode = PriceMode.BEST;
		if (instance.goalType == null) instance.goalType = GoalType.NONE;
		if (instance.theme == null) instance.theme = Theme.CLASSIC;
		if (instance.hiddenLines == null) instance.hiddenLines = new ArrayList<>();
		if (instance.lineOrder == null) instance.lineOrder = new ArrayList<>();
		if (instance.plotHighlightColor == 0) instance.plotHighlightColor = 0xFFFF5555;
		if (instance.hudScale < 0.5f || instance.hudScale > 3f) instance.hudScale = 1f;
		save();
	}

	public static void save() {
		try {
			Files.createDirectories(FILE.getParent());
			try (Writer writer = Files.newBufferedWriter(FILE)) {
				GSON.toJson(instance, writer);
			}
		} catch (Exception e) {
			GardenTracker.LOGGER.warn("Could not save gardentracker.json", e);
		}
	}
}
