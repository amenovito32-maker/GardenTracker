package dev.vito.gardentracker;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Saves each Garden visit (when you farmed for at least a minute) and lifetime totals per crop
 * to config/gardentracker-history.json.
 */
public final class History {
	public static final class Visit {
		public long endedAt;
		public long seconds;
		public double coins;
		public long cultivating;
		public double xp;
		public String mainCrop = "";

		public double coinsPerHour() {
			return seconds > 0 ? coins / seconds * 3600.0 : 0;
		}
	}

	public static final class CropTotal {
		public long crops;
		public double coins;
	}

	public static final class Data {
		public List<Visit> visits = new ArrayList<>();
		public Map<String, CropTotal> lifetime = new LinkedHashMap<>();
		public long lifetimeSeconds;
	}

	private static final int MAX_VISITS = 50;
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("gardentracker-history.json");
	private static Data data = new Data();

	// Snapshot of the session when the current Garden visit started.
	private static boolean visiting = false;
	private static double startCoins;
	private static long startCultivating;
	private static double startXp;
	private static long startSeconds;
	private static final Map<Crop, Long> startCrops = new EnumMap<>(Crop.class);
	private static boolean dirty = false;

	private History() {}

	public static Data data() {
		return data;
	}

	public static void load() {
		try {
			if (Files.exists(FILE)) {
				try (Reader reader = Files.newBufferedReader(FILE)) {
					Data loaded = GSON.fromJson(reader, Data.class);
					if (loaded != null) data = loaded;
				}
			}
		} catch (Exception e) {
			GardenTracker.LOGGER.warn("Could not read gardentracker-history.json", e);
		}
		if (data.visits == null) data.visits = new ArrayList<>();
		if (data.lifetime == null) data.lifetime = new LinkedHashMap<>();
	}

	public static void save() {
		if (!Config.get().saveHistory) return;
		try {
			Files.createDirectories(FILE.getParent());
			try (Writer writer = Files.newBufferedWriter(FILE)) {
				GSON.toJson(data, writer);
			}
			dirty = false;
		} catch (Exception e) {
			GardenTracker.LOGGER.warn("Could not save gardentracker-history.json", e);
		}
	}

	/** Lifetime totals, called whenever crops are counted. */
	public static void addCrops(Crop crop, long amount, double coins) {
		CropTotal total = data.lifetime.computeIfAbsent(crop.displayName, k -> new CropTotal());
		total.crops += amount;
		total.coins += coins;
		dirty = true;
	}

	public static void addSecond() {
		data.lifetimeSeconds++;
		dirty = true;
		if (data.lifetimeSeconds % 60 == 0) save(); // save about once a farming minute
	}

	public static void beginVisit() {
		visiting = true;
		startCoins = Session.coins;
		startCultivating = Session.cultivating;
		startXp = Session.xp;
		startSeconds = Session.activeSeconds;
		startCrops.clear();
		startCrops.putAll(Session.cropsByType);
	}

	/** Ends the current visit. Saved only if you farmed for at least 60 seconds. */
	public static void endVisit() {
		if (!visiting) return;
		visiting = false;
		long seconds = Session.activeSeconds - startSeconds;
		if (seconds >= 60) {
			Visit v = new Visit();
			v.endedAt = System.currentTimeMillis();
			v.seconds = seconds;
			v.coins = Session.coins - startCoins;
			v.cultivating = Session.cultivating - startCultivating;
			v.xp = Session.xp - startXp;
			Crop best = null;
			long bestAmount = 0;
			for (Map.Entry<Crop, Long> e : Session.cropsByType.entrySet()) {
				long amount = e.getValue() - startCrops.getOrDefault(e.getKey(), 0L);
				if (amount > bestAmount) {
					bestAmount = amount;
					best = e.getKey();
				}
			}
			v.mainCrop = best == null ? "-" : best.displayName;
			data.visits.add(0, v);
			while (data.visits.size() > MAX_VISITS) data.visits.remove(data.visits.size() - 1);
			dirty = true;
		}
		if (dirty) save();
	}

	public static void clear() {
		data = new Data();
		save();
	}
}
