package dev.vito.gardentracker;

/** HUD color themes. Colors are ARGB (alpha first). */
public enum Theme {
	CLASSIC("Classic", 0x90000000, 0x00000000, "§a§l", 0xFFAAAAAA, 0xFFFFFFFF, 0xFF55FF55),
	MIDNIGHT("Midnight", 0xC0101830, 0xFF4060C0, "§b§l", 0xFF8FA8D8, 0xFFFFFFFF, 0xFF55AAFF),
	FOREST("Forest", 0xB0102010, 0xFF3C8C3C, "§2§l", 0xFF9CCB8F, 0xFFF0FFE8, 0xFF7CD65C),
	SUNSET("Sunset", 0xB0301018, 0xFFE07040, "§6§l", 0xFFE8B090, 0xFFFFF4E8, 0xFFFFA040),
	CANDY("Candy", 0xB0301030, 0xFFE070D0, "§d§l", 0xFFE8A8E0, 0xFFFFFFFF, 0xFFFF77DD),
	MINIMAL("Minimal", 0x00000000, 0x00000000, "§f§l", 0xFFBBBBBB, 0xFFFFFFFF, 0xFFFFFFFF);

	public final String displayName;
	public final int background;
	public final int border;
	public final String titleStyle;
	public final int labelColor;
	public final int valueColor;
	public final int accent;

	Theme(String displayName, int background, int border, String titleStyle, int labelColor, int valueColor, int accent) {
		this.displayName = displayName;
		this.background = background;
		this.border = border;
		this.titleStyle = titleStyle;
		this.labelColor = labelColor;
		this.valueColor = valueColor;
		this.accent = accent;
	}

	public Theme next() {
		return values()[(ordinal() + 1) % values().length];
	}
}
