package dev.vito.gardentracker;

import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Small drawing helpers for the HUD and menu (rounded boxes, colors). */
public final class Ui {
	private Ui() {}

	/** Filled box with 2px rounded corners. */
	public static void round(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int color) {
		if (x2 - x1 < 4 || y2 - y1 < 4) {
			g.fill(x1, y1, x2, y2, color);
			return;
		}
		g.fill(x1 + 2, y1, x2 - 2, y2, color);
		g.fill(x1 + 1, y1 + 1, x1 + 2, y2 - 1, color);
		g.fill(x2 - 2, y1 + 1, x2 - 1, y2 - 1, color);
		g.fill(x1, y1 + 2, x1 + 1, y2 - 2, color);
		g.fill(x2 - 1, y1 + 2, x2, y2 - 2, color);
	}

	/** 1px rounded outline. */
	public static void roundOutline(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int color) {
		g.fill(x1 + 2, y1, x2 - 2, y1 + 1, color);
		g.fill(x1 + 2, y2 - 1, x2 - 2, y2, color);
		g.fill(x1, y1 + 2, x1 + 1, y2 - 2, color);
		g.fill(x2 - 1, y1 + 2, x2, y2 - 2, color);
		g.fill(x1 + 1, y1 + 1, x1 + 2, y1 + 2, color);
		g.fill(x2 - 2, y1 + 1, x2 - 1, y1 + 2, color);
		g.fill(x1 + 1, y2 - 2, x1 + 2, y2 - 1, color);
		g.fill(x2 - 2, y2 - 2, x2 - 1, y2 - 1, color);
	}

	/** Replaces the alpha of an ARGB color (alpha 0-255). */
	public static int alpha(int color, int alpha) {
		return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, alpha)) << 24);
	}

	/** Blends two ARGB colors, t = 0..1. */
	public static int mix(int a, int b, float t) {
		int aa = a >>> 24, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
		int ba = b >>> 24, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
		return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
				| ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
	}

	/** Color from hue (0-360) with full saturation and brightness. */
	public static int hue(float h) {
		int rgb = java.awt.Color.HSBtoRGB(h / 360f, 0.75f, 1f);
		return 0xFF000000 | (rgb & 0x00FFFFFF);
	}
}
