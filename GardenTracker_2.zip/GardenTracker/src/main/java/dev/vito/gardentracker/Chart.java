package dev.vito.gardentracker;

/**
 * Keeps a short history of your coin rate for the mini chart:
 * - one bar per 10 seconds, the last 60 bars (10 minutes)
 * - a "last 60 seconds" live rate
 */
public final class Chart {
	public static final int BARS = 60;
	private static final double[] bars = new double[BARS];     // coins/hr per 10s bucket
	private static int barCount = 0;
	private static final double[] perSecond = new double[60];  // coins earned each second
	private static int secondIndex = 0;
	private static double lastTotal = -1;
	private static double bucket = 0;
	private static int bucketSeconds = 0;

	private Chart() {}

	/** Called once per second while in the Garden with the session coin total. */
	public static void onSecond(double totalCoins) {
		if (lastTotal < 0 || totalCoins < lastTotal) lastTotal = totalCoins; // first call or session reset
		double earned = totalCoins - lastTotal;
		lastTotal = totalCoins;

		perSecond[secondIndex] = earned;
		secondIndex = (secondIndex + 1) % perSecond.length;

		bucket += earned;
		if (++bucketSeconds >= 10) {
			push(bucket * 360.0); // 10 s of coins -> coins per hour
			bucket = 0;
			bucketSeconds = 0;
		}
	}

	private static void push(double value) {
		if (barCount < BARS) {
			bars[barCount++] = value;
		} else {
			System.arraycopy(bars, 1, bars, 0, BARS - 1);
			bars[BARS - 1] = value;
		}
	}

	/** Coins per hour over the last 60 seconds. */
	public static double liveRate() {
		double sum = 0;
		for (double v : perSecond) sum += v;
		return sum * 60.0;
	}

	public static int count() {
		return barCount;
	}

	public static double bar(int i) {
		return bars[i];
	}

	public static double max() {
		double max = 0;
		for (int i = 0; i < barCount; i++) max = Math.max(max, bars[i]);
		return max;
	}

	public static void reset() {
		java.util.Arrays.fill(bars, 0);
		java.util.Arrays.fill(perSecond, 0);
		barCount = 0;
		secondIndex = 0;
		lastTotal = -1;
		bucket = 0;
		bucketSeconds = 0;
	}
}
