package dev.vito.gardentracker;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvents;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
import java.util.Map;
import java.util.function.Supplier;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommands.literal;

/**
 * Garden Tracker - a display-only helper for the Hypixel SkyBlock Garden.
 * It only reads what the game already shows you (tab list, action bar, held item, tooltips)
 * and public Hypixel price data. It never clicks, moves, farms or sends anything to the server.
 */
public final class GardenTracker implements ClientModInitializer {
	public static final String MOD_ID = "gardentracker";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	private static final String PREFIX = "§a[Garden Tracker] §r";

	private static final KeyMapping.Category KEY_CATEGORY = KeyMapping.Category.register(Identifier.fromNamespaceAndPath(MOD_ID, "main"));
	private static KeyMapping menuKey;

	/** A screen to open on the next tick (commands run while the chat screen is still closing). */
	private static Supplier<Screen> pendingScreen = null;

	private static int tickCounter = 0;
	private static boolean wasInGarden = false;
	private static boolean pestAlertShown = false;
	private static boolean queueFullShown = false;
	private static boolean afkAlertShown = false;

	@Override
	public void onInitializeClient() {
		Config.load();
		History.load();

		menuKey = KeyMappingHelper.registerKeyMapping(new KeyMapping("key.gardentracker.menu", GLFW.GLFW_KEY_O, KEY_CATEGORY));

		HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS,
				Identifier.fromNamespaceAndPath(MOD_ID, "garden_hud"), Hud::render);

		ClientTickEvents.END_CLIENT_TICK.register(GardenTracker::onTick);

		// In-world outline of plots with pests.
		LevelRenderEvents.END_MAIN.register(context -> WorldHighlight.render(context.levelState().cameraRenderState));

		// Observe the action bar for Farming XP. Always returns true, so the message is never hidden.
		ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
			if (GardenInfo.inGarden) {
				String plain = Text.stripColor(message.getString());
				if (overlay) Session.onActionBar(plain);
				else Plots.onChat(plain.trim());
			}
			return true;
		});

		ItemTooltipCallback.EVENT.register((stack, _, _, lines) -> VisitorTooltip.onTooltip(stack, lines));

		ClientPlayConnectionEvents.DISCONNECT.register((_, _) -> {
			if (wasInGarden) History.endVisit();
			GardenInfo.reset();
			Plots.reset();
			wasInGarden = false;
			Config.save();
		});

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, _) -> registerCommands(dispatcher));
		LOGGER.info("Garden Tracker loaded");
	}

	public static KeyMapping menuKey() {
		return menuKey;
	}

	private static void onTick(Minecraft mc) {
		// Every tick: open queued screens and check the hotkey.
		if (pendingScreen != null) {
			Supplier<Screen> s = pendingScreen;
			pendingScreen = null;
			mc.setScreen(s.get());
		}
		while (menuKey.consumeClick()) {
			if (mc.screen == null) mc.setScreen(new MenuScreen(null));
		}

		if (mc.player == null || mc.level == null) return;
		if (++tickCounter < 20) return; // the rest runs once per second
		tickCounter = 0;

		GardenInfo.update(mc);
		boolean inGarden = GardenInfo.inGarden;
		if (inGarden) {
			Plots.syncWithTab();
			Plots.readPlotMenu(mc);
		}

		if (!wasInGarden && inGarden) {
			History.beginVisit();
		}
		if (wasInGarden && !inGarden) {
			History.endVisit();
			Plots.reset();
			Config.save(); // keep personal records
			if (Config.get().summaryOnLeave && Session.hasData()) {
				printSummary(mc, "You left the Garden - session so far:");
			}
		}
		wasInGarden = inGarden;
		if (!inGarden) return;

		Prices.tick();
		Session.secondTick(mc);
		checkAlerts(mc);
	}

	private static void checkAlerts(Minecraft mc) {
		Config c = Config.get();

		// Pest alert: fires once when the pest count reaches your threshold.
		int pests = GardenInfo.pestsAlive;
		if (c.pestAlert && c.pestAlertThreshold > 0 && pests >= c.pestAlertThreshold) {
			if (!pestAlertShown) {
				pestAlertShown = true;
				StringBuilder list = new StringBuilder();
				for (Map.Entry<Integer, Integer> e : Plots.infested().entrySet()) {
					if (list.length() > 0) list.append(", ");
					list.append(Plots.name(e.getKey()));
					if (e.getValue() > 0) list.append(" (").append(e.getValue()).append(")");
				}
				String plots = list.length() == 0 ? "" : " in plots " + list;
				alert(mc, "§c" + pests + " Pests!", "§7" + (plots.isEmpty() ? "Time to clear them" : plots.trim()));
				say(mc, "§c" + pests + " pests alive" + plots + ".");
			}
		} else if (pests < c.pestAlertThreshold) {
			pestAlertShown = false;
		}

		// Visitor queue full: fires once until the queue has space again.
		boolean full = GardenInfo.nextVisitor.toLowerCase().contains("queue full");
		if (c.visitorQueueAlert && full && !queueFullShown) {
			queueFullShown = true;
			say(mc, "§eVisitor queue is full - new visitors won't arrive until you serve one.");
		} else if (!full) {
			queueFullShown = false;
		}

		// Stopped-farming alert: you were farming, still hold your tool, but nothing has been farmed for a while
		// (hit the end of a row, lagged, got moved, etc.). Fires once per stop.
		long last = Session.lastActivityMs();
		long idleSeconds = last == 0 ? 0 : (System.currentTimeMillis() - last) / 1000;
		boolean holdingTool = Session.currentCrop != null;
		if (c.afkAlertSeconds > 0 && holdingTool && last > 0 && idleSeconds >= c.afkAlertSeconds && idleSeconds < c.afkAlertSeconds + 120) {
			if (!afkAlertShown) {
				afkAlertShown = true;
				alert(mc, "§eStopped farming", "§7No crops for " + idleSeconds + "s");
			}
		} else if (idleSeconds < c.afkAlertSeconds) {
			afkAlertShown = false;
		}
	}

	private static void alert(Minecraft mc, String title, String subtitle) {
		mc.gui.setTitle(Component.literal(title));
		mc.gui.setSubtitle(Component.literal(subtitle));
		mc.gui.setTimes(5, 40, 10);
		if (Config.get().alertSounds) {
			mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_PLING.value(), 1.0f, 1.0f));
		}
	}

	static void say(Minecraft mc, String text) {
		if (mc.player != null) mc.player.sendSystemMessage(Component.literal(PREFIX + text));
	}

	/** Starts a new session (the current Garden visit is saved to history first). */
	static void resetSession() {
		boolean visiting = GardenInfo.inGarden;
		if (visiting) History.endVisit();
		Session.reset();
		if (visiting) History.beginVisit();
	}

	static void printSummary(Minecraft mc, String header) {
		Config c = Config.get();
		say(mc, "§f" + header);
		say(mc, "§7Farming time: §f" + Text.time(Session.activeSeconds));
		say(mc, "§6Coins: §f" + Text.commas(Math.round(Session.coins)) + " §8(" + Text.shortNum(Session.coinsPerHour()) + "/hr, " + c.priceMode.name().toLowerCase() + " prices)");
		say(mc, "§bCultivating: §f" + Text.commas(Session.cultivating) + " §8(" + Text.shortNum(Session.cultivatingPerHour()) + "/hr)");
		say(mc, "§dFarming XP: §f" + Text.commas(Math.round(Session.xp)) + " §8(" + Text.shortNum(Session.xpPerHour()) + "/hr)");
		Session.cropsByType.entrySet().stream()
				.sorted(Map.Entry.<Crop, Long>comparingByValue(Comparator.reverseOrder()))
				.forEach(e -> say(mc, "  §7" + e.getKey().displayName + ": §f" + Text.commas(e.getValue())
						+ " §8-> §6" + Text.shortNum(Session.coinsByType.getOrDefault(e.getKey(), 0.0)) + " coins"));
		if (c.bestCoinsPerHour > 0) {
			say(mc, "§7Records: §6" + Text.shortNum(c.bestCoinsPerHour) + " coins/hr§7, §b" + Text.shortNum(c.bestCultivatingPerHour)
					+ " cultivating/hr§7, §d" + Text.shortNum(c.bestXpPerHour) + " XP/hr");
		}
	}

	// ----- commands -----

	private static void registerCommands(CommandDispatcher<FabricClientCommandSource> dispatcher) {
		LiteralArgumentBuilder<FabricClientCommandSource> root = literal("gt")
				.executes(ctx -> open(() -> new MenuScreen(null)))
				.then(literal("menu").executes(ctx -> open(() -> new MenuScreen(null))))
				.then(literal("edit").executes(ctx -> open(() -> new HudEditorScreen(null))))
				.then(literal("help").executes(ctx -> help()))
				.then(literal("toggle").executes(ctx -> {
					Config.get().hudEnabled = !Config.get().hudEnabled;
					return saved("HUD " + (Config.get().hudEnabled ? "§aon" : "§coff"));
				}))
				.then(literal("stats").executes(ctx -> stats()))
				.then(literal("history").executes(ctx -> history()))
				.then(literal("reset").executes(ctx -> {
					resetSession();
					say(Minecraft.getInstance(), "Session reset.");
					return 1;
				}))
				.then(literal("pos").then(argument("x", IntegerArgumentType.integer(0, 4000))
						.then(argument("y", IntegerArgumentType.integer(0, 4000)).executes(ctx -> {
							Config.get().hudX = IntegerArgumentType.getInteger(ctx, "x");
							Config.get().hudY = IntegerArgumentType.getInteger(ctx, "y");
							return saved("HUD moved to " + Config.get().hudX + ", " + Config.get().hudY);
						}))))
				.then(literal("scale").then(argument("scale", FloatArgumentType.floatArg(0.5f, 3.0f)).executes(ctx -> {
					Config.get().hudScale = FloatArgumentType.getFloat(ctx, "scale");
					return saved("HUD scale " + Config.get().hudScale);
				})))
				.then(literal("price")
						.then(literal("best").executes(ctx -> price(Config.PriceMode.BEST)))
						.then(literal("npc").executes(ctx -> price(Config.PriceMode.NPC)))
						.then(literal("bazaar").executes(ctx -> price(Config.PriceMode.BAZAAR))))
				.then(literal("goal")
						.then(literal("none").executes(ctx -> goal(Config.GoalType.NONE)))
						.then(literal("cultivating").executes(ctx -> goal(Config.GoalType.CULTIVATING)))
						.then(literal("level").executes(ctx -> goal(Config.GoalType.LEVEL)))
						.then(literal("coins").then(argument("amount", LongArgumentType.longArg(1)).executes(ctx -> {
							Config.get().goalCoins = LongArgumentType.getLong(ctx, "amount");
							return goal(Config.GoalType.COINS);
						}))))
				.then(literal("refresh").executes(ctx -> {
					Prices.forceRefresh();
					say(Minecraft.getInstance(), "Prices will reload in a moment.");
					return 1;
				}));

		dispatcher.register(root);
		dispatcher.register(literal("gardenstats").executes(ctx -> stats()));
	}

	private static int open(Supplier<Screen> screen) {
		pendingScreen = screen;
		return 1;
	}

	private static int help() {
		Minecraft mc = Minecraft.getInstance();
		say(mc, "§fCommands (or press §eO§f to open the menu):");
		say(mc, "§e/gt §7- menu   §e/gt edit §7- move/resize HUD   §e/gt stats §7- summary");
		say(mc, "§e/gt history §7- past visits   §e/gt reset §7- new session   §e/gt toggle §7- show/hide HUD");
		say(mc, "§e/gt price best|npc|bazaar   §e/gt goal none|cultivating|level|coins <amount>");
		return 1;
	}

	private static int stats() {
		Minecraft mc = Minecraft.getInstance();
		if (!Session.hasData()) {
			say(mc, "No farming tracked yet this session.");
		} else {
			printSummary(mc, "Session summary:");
		}
		return 1;
	}

	private static int history() {
		Minecraft mc = Minecraft.getInstance();
		History.Data d = History.data();
		if (d.visits.isEmpty()) {
			say(mc, "No saved Garden visits yet (farm for at least a minute, then leave the Garden).");
			return 1;
		}
		SimpleDateFormat fmt = new SimpleDateFormat("MMM d HH:mm");
		say(mc, "§fLast Garden visits:");
		for (int i = 0; i < Math.min(10, d.visits.size()); i++) {
			History.Visit v = d.visits.get(i);
			say(mc, "§8" + fmt.format(new Date(v.endedAt)) + " §f" + v.mainCrop + " §7" + Text.time(v.seconds)
					+ " §6" + Text.shortNum(v.coins) + " coins (" + Text.shortNum(v.coinsPerHour()) + "/hr) §b"
					+ Text.shortNum(v.cultivating) + " cult. §d" + Text.shortNum(v.xp) + " XP");
		}
		return 1;
	}

	private static int price(Config.PriceMode mode) {
		Config.get().priceMode = mode;
		return saved("Prices: " + mode.name().toLowerCase() + " §8(applies to new crops; /gt reset to recount)");
	}

	private static int goal(Config.GoalType type) {
		Config.get().goalType = type;
		return saved("Goal: " + type.name().toLowerCase());
	}

	private static int saved(String message) {
		Config.save();
		say(Minecraft.getInstance(), message);
		return 1;
	}
}
