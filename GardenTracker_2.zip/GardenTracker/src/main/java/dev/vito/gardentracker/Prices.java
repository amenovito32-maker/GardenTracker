package dev.vito.gardentracker;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Loads prices from Hypixel's public SkyBlock endpoints (no API key needed):
 * - /v2/resources/skyblock/items : item names and NPC sell prices
 * - /v2/skyblock/bazaar          : Bazaar instant buy / sell prices
 * Downloads run in the background and never block the game.
 */
public final class Prices {
	private static final String ITEMS_URL = "https://api.hypixel.net/v2/resources/skyblock/items";
	private static final String BAZAAR_URL = "https://api.hypixel.net/v2/skyblock/bazaar";
	private static final long BAZAAR_REFRESH_MS = 5 * 60 * 1000L;

	private static final HttpClient CLIENT = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15)).build();

	private static final Map<String, Double> NPC = new ConcurrentHashMap<>();
	private static final Map<String, String> NAME_TO_ID = new ConcurrentHashMap<>();
	private static final Map<String, Double> BAZAAR_SELL = new ConcurrentHashMap<>();
	private static final Map<String, Double> BAZAAR_BUY = new ConcurrentHashMap<>();

	private static volatile boolean itemsLoaded = false;
	private static volatile boolean loadingItems = false;
	private static volatile boolean loadingBazaar = false;
	private static volatile long lastBazaarLoad = 0;

	private Prices() {}

	/** Called every second; starts downloads when needed. */
	public static void tick() {
		if (!itemsLoaded && !loadingItems) loadItems();
		if (!loadingBazaar && System.currentTimeMillis() - lastBazaarLoad > BAZAAR_REFRESH_MS) loadBazaar();
	}

	public static void forceRefresh() {
		lastBazaarLoad = 0;
		itemsLoaded = false;
	}

	private static void loadItems() {
		loadingItems = true;
		fetch(ITEMS_URL).whenComplete((json, error) -> {
			try {
				if (json != null && json.has("items")) {
					for (JsonElement element : json.getAsJsonArray("items")) {
						JsonObject item = element.getAsJsonObject();
						if (!item.has("id")) continue;
						String id = item.get("id").getAsString();
						if (item.has("npc_sell_price")) NPC.put(id, item.get("npc_sell_price").getAsDouble());
						if (item.has("name")) NAME_TO_ID.putIfAbsent(clean(item.get("name").getAsString()), id);
					}
					itemsLoaded = true;
				} else if (error != null) {
					GardenTracker.LOGGER.warn("Could not load Hypixel item list: {}", error.toString());
				}
			} catch (Exception e) {
				GardenTracker.LOGGER.warn("Could not read Hypixel item list", e);
			} finally {
				loadingItems = false;
			}
		});
	}

	private static void loadBazaar() {
		loadingBazaar = true;
		lastBazaarLoad = System.currentTimeMillis();
		fetch(BAZAAR_URL).whenComplete((json, error) -> {
			try {
				if (json != null && json.has("products")) {
					for (Map.Entry<String, JsonElement> entry : json.getAsJsonObject("products").entrySet()) {
						JsonObject product = entry.getValue().getAsJsonObject();
						if (!product.has("quick_status")) continue;
						JsonObject quick = product.getAsJsonObject("quick_status");
						// sellPrice = what you get when you instant-sell; buyPrice = what you pay to instant-buy.
						if (quick.has("sellPrice")) BAZAAR_SELL.put(entry.getKey(), quick.get("sellPrice").getAsDouble());
						if (quick.has("buyPrice")) BAZAAR_BUY.put(entry.getKey(), quick.get("buyPrice").getAsDouble());
					}
				} else if (error != null) {
					GardenTracker.LOGGER.warn("Could not load Bazaar prices: {}", error.toString());
				}
			} catch (Exception e) {
				GardenTracker.LOGGER.warn("Could not read Bazaar prices", e);
			} finally {
				loadingBazaar = false;
			}
		});
	}

	private static java.util.concurrent.CompletableFuture<JsonObject> fetch(String url) {
		HttpRequest request = HttpRequest.newBuilder(URI.create(url))
				.timeout(Duration.ofSeconds(30))
				.header("User-Agent", "GardenTracker-Mod")
				.GET()
				.build();
		return CLIENT.sendAsync(request, HttpResponse.BodyHandlers.ofString())
				.thenApply(response -> response.statusCode() == 200
						? JsonParser.parseString(response.body()).getAsJsonObject()
						: null);
	}

	public static double npcPrice(String id) {
		return NPC.getOrDefault(id, 0.0);
	}

	public static double bazaarSellPrice(String id) {
		return BAZAAR_SELL.getOrDefault(id, 0.0);
	}

	public static double bazaarBuyPrice(String id) {
		return BAZAAR_BUY.getOrDefault(id, 0.0);
	}

	/** Looks up a SkyBlock item ID from a display name such as "Enchanted Hay Bale". */
	public static String idFromName(String name) {
		return NAME_TO_ID.get(clean(name));
	}

	public static boolean hasBazaar() {
		return !BAZAAR_SELL.isEmpty();
	}

	private static String clean(String name) {
		return Text.stripColor(name).trim().toLowerCase(Locale.ROOT);
	}
}
