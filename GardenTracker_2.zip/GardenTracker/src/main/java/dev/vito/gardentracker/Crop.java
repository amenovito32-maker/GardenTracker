package dev.vito.gardentracker;

/**
 * Garden crops, the farming tool ID prefix used to detect them, and the item ID used for prices.
 * Tool prefixes and item IDs follow SkyHanni's CropType list.
 * NPC fallback prices are only used until the Hypixel item list has loaded (0 = unknown).
 */
public enum Crop {
	WHEAT("Wheat", "THEORETICAL_HOE_WHEAT", "WHEAT", 6),
	CARROT("Carrot", "THEORETICAL_HOE_CARROT", "CARROT_ITEM", 3),
	POTATO("Potato", "THEORETICAL_HOE_POTATO", "POTATO_ITEM", 3),
	NETHER_WART("Nether Wart", "THEORETICAL_HOE_WARTS", "NETHER_STALK", 4),
	PUMPKIN("Pumpkin", "PUMPKIN_DICER", "PUMPKIN", 10),
	MELON("Melon", "MELON_DICER", "MELON", 2),
	COCOA("Cocoa Beans", "COCO_CHOPPER", "INK_SACK:3", 3),
	SUGAR_CANE("Sugar Cane", "THEORETICAL_HOE_CANE", "SUGAR_CANE", 4),
	CACTUS("Cactus", "CACTUS_KNIFE", "CACTUS", 4),
	MUSHROOM("Mushroom", "FUNGI_CUTTER", "RED_MUSHROOM", 10),
	// Sunflower and Moonflower share one hoe, so they are tracked together.
	SUNFLOWER("Sun/Moonflower", "THEORETICAL_HOE_SUNFLOWER", "DOUBLE_PLANT", 0),
	WILD_ROSE("Wild Rose", "THEORETICAL_HOE_WILD_ROSE", "WILD_ROSE", 0);

	public final String displayName;
	public final String toolPrefix;
	public final String itemId;
	public final double npcFallback;

	Crop(String displayName, String toolPrefix, String itemId, double npcFallback) {
		this.displayName = displayName;
		this.toolPrefix = toolPrefix;
		this.itemId = itemId;
		this.npcFallback = npcFallback;
	}

	/** Returns the crop for a SkyBlock tool ID such as THEORETICAL_HOE_WHEAT_3, or null. */
	public static Crop fromToolId(String toolId) {
		if (toolId == null || toolId.isEmpty()) return null;
		for (Crop crop : values()) {
			if (toolId.startsWith(crop.toolPrefix)) return crop;
		}
		return null;
	}

	/** Coins for one crop, based on the selected price mode. */
	public double price(Config.PriceMode mode) {
		double npc = Prices.npcPrice(itemId);
		if (npc <= 0) npc = npcFallback;
		double bazaar = Prices.bazaarSellPrice(itemId);
		return switch (mode) {
			case NPC -> npc;
			case BAZAAR -> bazaar > 0 ? bazaar : npc;
			case BEST -> Math.max(npc, bazaar);
		};
	}
}
