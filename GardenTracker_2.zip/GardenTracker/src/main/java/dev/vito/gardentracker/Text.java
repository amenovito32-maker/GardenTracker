package dev.vito.gardentracker;

import java.util.Locale;
import java.util.regex.Pattern;

/** Small text helpers: removing § color codes and formatting numbers and times. */
public final class Text {
	private static final Pattern COLOR = Pattern.compile("§.");

	private Text() {}

	public static String stripColor(String s) {
		return s == null ? "" : COLOR.matcher(s).replaceAll("");
	}

	/** 1234 -> 1.2k, 1234567 -> 1.23M, 1234567890 -> 1.23B */
	public static String shortNum(double v) {
		double a = Math.abs(v);
		if (a >= 1e9) return String.format(Locale.ROOT, "%.2fB", v / 1e9);
		if (a >= 1e6) return String.format(Locale.ROOT, "%.2fM", v / 1e6);
		if (a >= 1e3) return String.format(Locale.ROOT, "%.1fk", v / 1e3);
		return String.format(Locale.ROOT, "%.0f", v);
	}

	/** Short or full number, following the "Short numbers" setting. */
	public static String num(double v) {
		return Config.get().shortNumbers ? shortNum(v) : commas(Math.round(v));
	}

	/** 1234567 -> 1,234,567 */
	public static String commas(long v) {
		return String.format(Locale.ROOT, "%,d", v);
	}

	/** Seconds -> "1h 02m", "3m 05s" or "45s". */
	public static String time(long seconds) {
		if (seconds < 0) seconds = 0;
		long h = seconds / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
		if (h > 0) return String.format(Locale.ROOT, "%dh %02dm", h, m);
		if (m > 0) return String.format(Locale.ROOT, "%dm %02ds", m, s);
		return s + "s";
	}

	/** Parses numbers like "1,234.5", "750", "1.5k", "2M". Returns -1 if it can't. */
	public static double parseNum(String raw) {
		if (raw == null) return -1;
		String s = raw.replace(",", "").trim().toLowerCase(Locale.ROOT);
		if (s.isEmpty()) return -1;
		double mult = 1;
		char last = s.charAt(s.length() - 1);
		if (last == 'k') mult = 1e3;
		else if (last == 'm') mult = 1e6;
		else if (last == 'b') mult = 1e9;
		if (mult != 1) s = s.substring(0, s.length() - 1);
		try {
			return Double.parseDouble(s) * mult;
		} catch (NumberFormatException e) {
			return -1;
		}
	}

	/** Roman numeral for 1..10 (used for Cultivating tiers). */
	public static String roman(int n) {
		String[] r = {"0", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
		return n >= 0 && n < r.length ? r[n] : String.valueOf(n);
	}
}
