package dev.vito.gardentracker;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ItemLore;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Garden plot layout and pests per plot.
 *
 * Layout (from SkyHanni's GardenPlotApi): a 5x5 grid of 96x96 plots centred on 0,0. The number is the plot ID,
 * 0 is the Barn. Default plot names are their IDs ("1".."24"); renamed plots are learned from the Configure Plots menu.
 *
 * Pests per plot come from (most reliable first):
 *  1. the Configure Plots menu lore ("This plot has 3 Pests!")
 *  2. pest spawn chat messages ("YUCK! 4 Pests have spawned in Plot - 14!")
 *  3. the tab list ("Alive: 5", "Plots: 4, 12") to remove cleared plots and fix totals
 */
public final class Plots {
	public static final int[][] LAYOUT = {
			{21, 13, 9, 14, 22},
			{15, 5, 1, 6, 16},
			{10, 2, 0, 3, 11},
			{17, 7, 4, 8, 18},
			{23, 19, 12, 20, 24},
	};
	public static final int SIZE = 96;
	public static final int MIN_Y = 66;   // lowest point in the Garden (SkyHanni)
	public static final int MAX_Y = 102;  // build limit

	private static final Pattern ONE_PEST = Pattern.compile("^\\w+! A .{0,3}Pest has appeared in (?:Plot - )?(.+)!$");
	private static final Pattern MANY_PESTS = Pattern.compile("^\\w+! (\\d+) .{0,3}Pests? have spawned in (?:Plot - )?(.+)!$");
	private static final Pattern MENU_PEST_COUNT = Pattern.compile("This plot has (\\d+) .{0,3}Pests?!");
	private static final Pattern MENU_PLOT_NAME = Pattern.compile("^Plot - (.+)$");

	/** id -> display name (defaults to the id). */
	private static final Map<Integer, String> names = new HashMap<>();
	/** id -> pests (-1 = has pests, count unknown). Only infested plots are present. */
	private static final Map<Integer, Integer> pests = new LinkedHashMap<>();
	/** id -> time of the last spawn message, so a fresh spawn isn't dropped before the tab list catches up. */
	private static final Map<Integer, Long> recentSpawn = new HashMap<>();
	private static int lastAlive = -1;

	private Plots() {}

	public static String name(int id) {
		if (id == 0) return "Barn";
		return names.getOrDefault(id, String.valueOf(id));
	}

	/** Grid column/row (0..4) of a plot id, or null. */
	public static int[] cell(int id) {
		for (int row = 0; row < 5; row++)
			for (int col = 0; col < 5; col++)
				if (LAYOUT[row][col] == id) return new int[]{col, row};
		return null;
	}

	public static int minX(int id) {
		int[] c = cell(id);
		return c == null ? 0 : (c[0] - 2) * SIZE - SIZE / 2;
	}

	public static int minZ(int id) {
		int[] c = cell(id);
		return c == null ? 0 : (c[1] - 2) * SIZE - SIZE / 2;
	}

	/** Plot id at a world position, or -1 outside the grid. */
	public static int idAt(double x, double z) {
		int col = (int) Math.floor((x + SIZE * 2.5) / SIZE);
		int row = (int) Math.floor((z + SIZE * 2.5) / SIZE);
		if (col < 0 || col > 4 || row < 0 || row > 4) return -1;
		return LAYOUT[row][col];
	}

	public static int currentPlot() {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null || !GardenInfo.inGarden) return -1;
		return idAt(mc.player.position().x(), mc.player.position().z());
	}

	/** Infested plots: id -> pest count (-1 = unknown). */
	public static Map<Integer, Integer> infested() {
		return pests;
	}

	/** Finds a plot id from a name like "4", "Plot - 4", "The Barn" or a custom name. */
	public static int idFromName(String raw) {
		String name = Text.stripColor(raw).replace("Plot - ", "").trim();
		if (name.equalsIgnoreCase("The Barn") || name.equalsIgnoreCase("Barn")) return 0;
		for (Map.Entry<Integer, String> e : names.entrySet()) {
			if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
		}
		String digits = name.replaceAll("[^0-9 ]", " ").trim();
		if (!digits.isEmpty()) {
			String[] parts = digits.split("\\s+");
			try {
				int id = Integer.parseInt(parts[parts.length - 1]);
				if (id >= 1 && id <= 24) return id;
			} catch (NumberFormatException ignored) {
			}
		}
		return -1;
	}

	// ----- inputs -----

	/** Chat (not action bar) messages. */
	public static void onChat(String plain) {
		Matcher m = MANY_PESTS.matcher(plain);
		if (m.matches()) {
			add(idFromName(m.group(2)), Integer.parseInt(m.group(1)));
			return;
		}
		m = ONE_PEST.matcher(plain);
		if (m.matches()) add(idFromName(m.group(1)), 1);
	}

	private static void add(int id, int amount) {
		if (id < 0) return;
		int now = pests.getOrDefault(id, 0);
		pests.put(id, (now < 0 ? 0 : now) + amount);
		recentSpawn.put(id, System.currentTimeMillis());
	}

	/** Called once a second after the tab list is read. */
	public static void syncWithTab() {
		if (!GardenInfo.inGarden) return;
		int alive = GardenInfo.pestsAlive;
		if (alive == 0) {
			pests.clear();
			lastAlive = 0;
			return;
		}

		// Drop plots the tab list no longer lists, add listed ones we didn't know about.
		if (!GardenInfo.infestedPlots.isEmpty()) {
			Map<Integer, Integer> keep = new LinkedHashMap<>();
			for (String part : GardenInfo.infestedPlots.split(",")) {
				int id = idFromName(part);
				if (id >= 0) keep.put(id, pests.getOrDefault(id, -1));
			}
			long now = System.currentTimeMillis();
			for (Map.Entry<Integer, Long> e : recentSpawn.entrySet()) {
				if (now - e.getValue() < 5000 && pests.containsKey(e.getKey())) keep.putIfAbsent(e.getKey(), pests.get(e.getKey()));
			}
			pests.clear();
			pests.putAll(keep);
		}

		// A pest died: most likely in the plot you're standing in.
		if (lastAlive > 0 && alive >= 0 && alive < lastAlive) {
			int here = currentPlot();
			int removed = lastAlive - alive;
			Integer count = pests.get(here);
			if (count != null && count > 0) pests.put(here, Math.max(1, count - removed));
		}
		lastAlive = alive;

		// With one infested plot, all alive pests are there.
		if (pests.size() == 1 && alive > 0) {
			int only = pests.keySet().iterator().next();
			pests.put(only, alive);
		}
		// Never show more pests in total than are alive.
		int known = 0;
		for (int v : pests.values()) if (v > 0) known += v;
		if (alive > 0 && known > alive) {
			for (Map.Entry<Integer, Integer> e : pests.entrySet()) if (e.getValue() > 0) e.setValue(-1);
		}
	}

	/** Reads plot names and pest counts while the Configure Plots menu is open. */
	public static void readPlotMenu(Minecraft mc) {
		if (!(mc.screen instanceof AbstractContainerScreen<?> screen)) return;
		if (!screen.getTitle().getString().contains("Configure Plots")) return;
		var menu = screen.getMenu();
		Map<Integer, Integer> fromMenu = new LinkedHashMap<>();
		boolean sawAny = false;
		for (int row = 0; row < 5; row++) {
			for (int col = 0; col < 5; col++) {
				int slot = 2 + row * 9 + col;
				if (slot >= menu.slots.size()) return;
				ItemStack stack = menu.getSlot(slot).getItem();
				if (stack.isEmpty()) continue;
				int id = LAYOUT[row][col];
				sawAny = true;
				Matcher nm = MENU_PLOT_NAME.matcher(Text.stripColor(stack.getHoverName().getString()).trim());
				if (nm.matches() && id != 0) names.put(id, nm.group(1).trim());
				ItemLore lore = stack.get(DataComponents.LORE);
				if (lore == null) continue;
				for (Component line : lore.lines()) {
					Matcher pm = MENU_PEST_COUNT.matcher(Text.stripColor(line.getString()));
					if (pm.find()) fromMenu.put(id, Integer.parseInt(pm.group(1)));
				}
			}
		}
		if (sawAny) {
			pests.clear();
			pests.putAll(fromMenu);
		}
	}

	public static void reset() {
		pests.clear();
		recentSpawn.clear();
		lastAlive = -1;
	}

	public static String describe(int id) {
		Integer n = pests.get(id);
		String count = n == null ? "0" : n < 0 ? "?" : String.valueOf(n);
		return String.format(Locale.ROOT, "%s: %s", name(id), count);
	}
}
