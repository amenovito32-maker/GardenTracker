package dev.vito.gardentracker;

/** Every line the HUD can show. Each one can be turned on or off in the menu. */
public enum HudLine {
	CROP("Crop", "Crop"),
	COINS("Coins/hr", "$/h"),
	CULTIVATING("Cultivating/hr", "Cult/h"),
	XP("Farming XP/hr", "XP/h"),
	LIVE_RATE("Last 60s", "Now"),
	SESSION("Session", "Time"),
	CHART("Coins chart", "Chart"),
	PESTS("Pests", "Pests"),
	PEST_COOLDOWN("Pest spawn", "Spawn"),
	PLOT_MAP("Plot map", "Map"),
	VISITORS("Visitors", "Vis"),
	GOAL("Goal", "Goal");

	public final String label;
	public final String shortLabel;

	HudLine(String label, String shortLabel) {
		this.label = label;
		this.shortLabel = shortLabel;
	}
}
