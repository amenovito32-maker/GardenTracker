package dev.vito.gardentracker;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Adds an offer breakdown to a visitor's "Accept Offer" tooltip:
 * cost of the requested items, copper reward, coins per copper, reward item value and a verdict.
 * Tooltip layout ("Items Required:" ... "Rewards:" ... "+20 Copper") follows SkyHanni's visitor parser.
 */
public final class VisitorTooltip {
	private static final Pattern ITEM_LINE = Pattern.compile("^(.+?)(?: x([\\d,]+))?$");
	private static final Pattern STAT_REWARD = Pattern.compile("^\\+\\s*([\\d.,]+[kKmM]?) (Copper|Garden Experience|Farming XP|Bits|Mithril Powder|Gemstone Powder)\\b.*");

	private VisitorTooltip() {}

	public static void onTooltip(ItemStack stack, List<Component> lines) {
		Config c = Config.get();
		if (!c.visitorCostTooltip || !GardenInfo.inGarden) return;
		if (!Text.stripColor(stack.getHoverName().getString()).trim().equals("Accept Offer")) return;

		double cost = 0;
		int unpricedCost = 0;
		double copper = 0;
		double rewardValue = 0;
		int section = 0; // 0 = before, 1 = items required, 2 = rewards
		for (Component line : List.copyOf(lines)) {
			String plain = Text.stripColor(line.getString()).trim();
			if (plain.isEmpty()) continue;
			if (plain.startsWith("Items Required")) { section = 1; continue; }
			if (plain.startsWith("Rewards")) { section = 2; continue; }
			if (section == 0) continue;

			if (section == 1) {
				Matcher m = ITEM_LINE.matcher(plain);
				if (!m.matches()) continue;
				long amount = m.group(2) == null ? 1 : Long.parseLong(m.group(2).replace(",", ""));
				String id = Prices.idFromName(m.group(1).trim());
				double price = id == null ? 0 : Prices.bazaarBuyPrice(id);
				if (price <= 0) unpricedCost++;
				else cost += price * amount;
			} else {
				Matcher stat = STAT_REWARD.matcher(plain);
				if (stat.matches()) {
					if (stat.group(2).equals("Copper")) copper += Text.parseNum(stat.group(1));
					continue;
				}
				// Other reward lines may be items (e.g. "Dedication IV" books, rare drops). Value them if the Bazaar knows them.
				String name = plain.startsWith("+") ? plain.substring(1).trim() : plain;
				Matcher m = ITEM_LINE.matcher(name);
				if (!m.matches()) continue;
				long amount = m.group(2) == null ? 1 : Long.parseLong(m.group(2).replace(",", ""));
				String id = Prices.idFromName(m.group(1).trim());
				if (id != null) rewardValue += Prices.bazaarSellPrice(id) * amount;
			}
		}
		if (section == 0) return;

		lines.add(Component.literal(""));
		lines.add(Component.literal("§a§lGarden Tracker"));
		if (cost > 0) lines.add(Component.literal("§7Cost to buy: §6" + Text.commas(Math.round(cost)) + " coins"));
		if (unpricedCost > 0) lines.add(Component.literal("§8" + unpricedCost + " requested item(s) not priced"));
		if (rewardValue > 0) lines.add(Component.literal("§7Reward items: §a" + Text.commas(Math.round(rewardValue)) + " coins"));
		if (copper > 0) {
			double net = cost - rewardValue;
			double perCopper = net / copper;
			lines.add(Component.literal("§7Copper: §c" + Text.commas(Math.round(copper))
					+ (net > 0 ? " §8(" + Text.commas(Math.round(perCopper)) + " coins each)" : "")));
		}

		// Verdict
		double net = cost - rewardValue;
		if (cost > 0 || rewardValue > 0) {
			String verdict;
			if (net <= 0) verdict = "§a§lPROFIT §r§a+" + Text.shortNum(-net) + " coins";
			else if (copper > 0 && net / copper <= c.coinsPerCopper) verdict = "§a✔ Good copper deal §8(≤ " + Text.shortNum(c.coinsPerCopper) + "/copper)";
			else if (copper > 0) verdict = "§c✘ Pricey copper §8(> " + Text.shortNum(c.coinsPerCopper) + "/copper)";
			else verdict = "§e Costs " + Text.shortNum(net) + " coins";
			lines.add(Component.literal(verdict));
		}
		lines.add(Component.literal(String.format(Locale.ROOT, "§8Bazaar prices%s", Prices.hasBazaar() ? "" : " loading...")));
	}
}
