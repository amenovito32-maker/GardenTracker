package dev.vito.gardentracker;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads Garden information from the tab list (refreshed once per second).
 * Line formats follow the patterns SkyHanni and NoFrills use:
 *   "Area: Garden", " Alive: 3", " Plots: 4, 12, 13", " Visitors: (3)", " Next Visitor: 1m 20s"
 */
public final class GardenInfo {
	private static final Pattern ALIVE = Pattern.compile("^Alive: (\\d+)");
	private static final Pattern PLOTS = Pattern.compile("^Plots: (.+)");
	private static final Pattern VISITORS = Pattern.compile("^Visitors: \\((\\d+)\\)");
	private static final Pattern NEXT_VISITOR = Pattern.compile("^Next Visitor: (.+)");
	/** Pest spawn cooldown, e.g. "Cooldown: 58s", "Cooldown: READY", "Cooldown: MAX PESTS" (format from SkyHanni). */
	private static final Pattern PEST_COOLDOWN = Pattern.compile("^Cooldown: (.+)");

	public static boolean inGarden = false;
	public static int pestsAlive = -1;
	public static String infestedPlots = "";
	public static int visitors = -1;
	public static String nextVisitor = "";
	public static String pestCooldown = "";

	private GardenInfo() {}

	public static void update(Minecraft mc) {
		ClientPacketListener connection = mc.getConnection();
		if (connection == null) {
			reset();
			return;
		}
		boolean garden = false;
		int alive = -1;
		String plots = "";
		int visitorCount = -1;
		String next = "";
		String cooldown = "";

		for (PlayerInfo info : connection.getOnlinePlayers()) {
			Component name = info.getTabListDisplayName();
			if (name == null) continue;
			String line = Text.stripColor(name.getString()).trim();
			if (line.isEmpty()) continue;

			if (line.startsWith("Area: ")) {
				garden = line.substring(6).trim().equals("Garden");
				continue;
			}
			Matcher m;
			if ((m = ALIVE.matcher(line)).find()) alive = Integer.parseInt(m.group(1));
			else if ((m = PLOTS.matcher(line)).find()) plots = m.group(1).trim();
			else if ((m = VISITORS.matcher(line)).find()) visitorCount = Integer.parseInt(m.group(1));
			else if ((m = NEXT_VISITOR.matcher(line)).find()) next = m.group(1).trim();
			else if ((m = PEST_COOLDOWN.matcher(line)).find()) cooldown = m.group(1).trim();
		}

		inGarden = garden;
		pestsAlive = garden ? alive : -1;
		infestedPlots = garden ? plots : "";
		visitors = garden ? visitorCount : -1;
		nextVisitor = garden ? next : "";
		pestCooldown = garden ? cooldown : "";
	}

	public static void reset() {
		inGarden = false;
		pestsAlive = -1;
		infestedPlots = "";
		visitors = -1;
		nextVisitor = "";
		pestCooldown = "";
	}
}
