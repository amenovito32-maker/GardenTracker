package dev.vito.gardentracker;

import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

import java.util.EnumMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tracks one farming session. Everything is read-only:
 * - Cultivating: the "farmed_cultivating" counter on the held farming tool (same field SkyHanni reads).
 * - Coins: Cultivating gained x price of that crop (an estimate; rare drops and pest loot are not included).
 * - Farming XP: the "+X Farming (current/needed)" part of the action bar.
 * The timer only counts seconds where you actually farmed, so AFK time does not lower your rates.
 */
public final class Session {
	/** Counter needed for Cultivating I..X (Hypixel SkyBlock Wiki, minecraft.wiki). */
	public static final long[] CULTIVATING_TIERS = {0, 1_000, 5_000, 25_000, 100_000, 250_000, 1_000_000, 2_500_000, 10_000_000, 25_000_000};

	private static final Pattern XP_NUMBERS = Pattern.compile("\\+([\\d.,]+) Farming \\(([\\d.,]+)/([\\d.,]+[kKmMbB]?)\\)");
	private static final Pattern XP_PERCENT = Pattern.compile("\\+([\\d.,]+) Farming \\(([\\d.,]+)%\\)");

	// Totals
	public static long cultivating = 0;
	public static double coins = 0;
	public static double xp = 0;
	public static final Map<Crop, Long> cropsByType = new EnumMap<>(Crop.class);
	public static final Map<Crop, Double> coinsByType = new EnumMap<>(Crop.class);

	// Time
	public static long activeSeconds = 0;
	private static long lastActivityMs = 0;

	// Held tool
	public static Crop currentCrop = null;
	public static long toolCounter = -1;
	private static String lastToolKey = "";
	private static long lastCounter = -1;

	// Farming XP progress (for the level goal)
	public static double xpCurrent = -1;
	public static double xpNeeded = -1;
	public static double xpPercent = -1;
	private static String lastPercentSegment = "";

	private Session() {}

	public static void reset() {
		cultivating = 0;
		coins = 0;
		xp = 0;
		cropsByType.clear();
		coinsByType.clear();
		activeSeconds = 0;
		lastActivityMs = 0;
		lastToolKey = "";
		lastCounter = -1;
		lastPercentSegment = "";
		Chart.reset();
	}

	/** When you last farmed (ms since epoch), 0 if never. */
	public static long lastActivityMs() {
		return lastActivityMs;
	}

	public static boolean hasData() {
		return cultivating > 0 || xp > 0;
	}

	public static boolean isActive() {
		return System.currentTimeMillis() - lastActivityMs <= Config.get().pauseSeconds * 1000L;
	}

	/** Called once per second while in the Garden. */
	public static void secondTick(Minecraft mc) {
		readHeldTool(mc);
		if (lastActivityMs > 0 && isActive()) {
			activeSeconds++;
			History.addSecond();
		}
		Chart.onSecond(coins);
		updateRecords();
	}

	private static void readHeldTool(Minecraft mc) {
		if (mc.player == null) return;
		ItemStack stack = mc.player.getMainHandItem();
		CompoundTag data = customData(stack);
		if (data == null) {
			currentCrop = null;
			toolCounter = -1;
			return;
		}
		String id = data.getStringOr("id", "");
		long counter = data.getLongOr("farmed_cultivating", -1L);
		Crop crop = Crop.fromToolId(id);
		if (crop == null || counter < 0) {
			currentCrop = null;
			toolCounter = -1;
			return;
		}
		currentCrop = crop;
		toolCounter = counter;

		String key = id + "|" + data.getStringOr("uuid", "");
		if (!key.equals(lastToolKey)) {
			// Switched tools: start counting from this tool's current value.
			lastToolKey = key;
			lastCounter = counter;
			return;
		}
		long delta = counter - lastCounter;
		lastCounter = counter;
		// Ignore impossible jumps (e.g. Hypixel resyncing the item).
		if (delta <= 0 || delta > 200_000) return;

		cultivating += delta;
		double earned = delta * crop.price(Config.get().priceMode);
		coins += earned;
		cropsByType.merge(crop, delta, Long::sum);
		coinsByType.merge(crop, earned, Double::sum);
		History.addCrops(crop, delta, earned);
		markActive();
	}

	/** Reads the action bar for Farming XP. Only called while in the Garden. */
	public static void onActionBar(String plain) {
		for (String segment : plain.split(" {2,}")) {
			segment = segment.trim();
			Matcher m = XP_NUMBERS.matcher(segment);
			if (m.find()) {
				double gained = Text.parseNum(m.group(1));
				double current = Text.parseNum(m.group(2));
				double needed = Text.parseNum(m.group(3));
				double delta;
				if (xpCurrent < 0) {
					delta = gained;                                    // first message we see
				} else if (current >= xpCurrent) {
					delta = current - xpCurrent;                       // 0 when the same message repeats
				} else {
					delta = xpNeeded > 0 ? (xpNeeded - xpCurrent) + current : gained; // level up
				}
				if (delta > gained * 20 + 1) delta = gained;           // safety against odd jumps
				xpCurrent = current;
				xpNeeded = needed;
				xpPercent = needed > 0 ? current / needed * 100 : -1;
				addXp(delta);
				return;
			}
			m = XP_PERCENT.matcher(segment);
			if (m.find()) {
				xpPercent = Text.parseNum(m.group(2));
				xpCurrent = -1;
				xpNeeded = -1;
				if (!segment.equals(lastPercentSegment)) {
					lastPercentSegment = segment;
					addXp(Text.parseNum(m.group(1)));
				}
				return;
			}
		}
	}

	private static void addXp(double amount) {
		if (amount <= 0) return;
		xp += amount;
		markActive();
	}

	private static void markActive() {
		lastActivityMs = System.currentTimeMillis();
	}

	// ----- rates -----

	public static double perHour(double total) {
		if (activeSeconds < 5) return 0;
		return total / activeSeconds * 3600.0;
	}

	public static double coinsPerHour() {
		return perHour(coins);
	}

	public static double cultivatingPerHour() {
		return perHour(cultivating);
	}

	public static double xpPerHour() {
		return perHour(xp);
	}

	private static void updateRecords() {
		if (activeSeconds < 300) return; // only count sessions of 5+ farming minutes
		Config c = Config.get();
		boolean changed = false;
		if (coinsPerHour() > c.bestCoinsPerHour) { c.bestCoinsPerHour = coinsPerHour(); changed = true; }
		if (cultivatingPerHour() > c.bestCultivatingPerHour) { c.bestCultivatingPerHour = cultivatingPerHour(); changed = true; }
		if (xpPerHour() > c.bestXpPerHour) { c.bestXpPerHour = xpPerHour(); changed = true; }
		if (changed && activeSeconds % 60 == 0) Config.save();
	}

	// ----- Cultivating tiers -----

	/** Current Cultivating tier (1..10) for a counter value. */
	public static int cultivatingTier(long counter) {
		int tier = 1;
		for (int i = 0; i < CULTIVATING_TIERS.length; i++) {
			if (counter >= CULTIVATING_TIERS[i]) tier = i + 1;
		}
		return tier;
	}

	public static CompoundTag customData(ItemStack stack) {
		if (stack == null || stack.isEmpty()) return null;
		CustomData data = stack.get(DataComponents.CUSTOM_DATA);
		return data == null ? null : data.copyTag();
	}
}
