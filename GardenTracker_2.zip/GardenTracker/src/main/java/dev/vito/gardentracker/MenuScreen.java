package dev.vito.gardentracker;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;

/**
 * The Garden Tracker menu, drawn by hand (no vanilla buttons): a sidebar, cards, switches, sliders and swatches.
 * It's an "immediate mode" UI: each frame the page is drawn and clickable areas are recorded for the next click.
 */
public final class MenuScreen extends Screen {
	private enum Page {
		DASHBOARD("★", "Dashboard", "Your session at a glance"),
		APPEARANCE("✎", "Appearance", "Make the HUD yours"),
		LAYOUT("☰", "Layout", "Choose and order the HUD lines"),
		TRACKING("⌚", "Tracking", "Prices, goals and the session timer"),
		PESTS("⚠", "Pests", "Plot highlights and the plot map"),
		ALERTS("♪", "Alerts", "Titles, sounds and summaries"),
		VISITORS("☺", "Visitors", "Offer breakdown on Accept Offer"),
		HISTORY("✦", "History", "Past Garden visits and lifetime totals");

		final String icon, title, subtitle;

		Page(String icon, String title, String subtitle) {
			this.icon = icon;
			this.title = title;
			this.subtitle = subtitle;
		}
	}

	// Palette
	private static final int BG = 0xF2101114;
	private static final int SIDEBAR = 0xFF15171C;
	private static final int CARD = 0xFF1C1F26;
	private static final int CARD_HOVER = 0xFF232733;
	private static final int TEXT = 0xFFE8EAF0;
	private static final int MUTED = 0xFF8A90A0;
	private static final int FAINT = 0xFF4A4F5C;
	private static final int TRACK = 0xFF343844;

	private static final int SIDEBAR_W = 96;
	private static final int ROW_H = 24;
	private static Page lastPage = Page.DASHBOARD;

	private static final int[] SWATCHES = {
			0, 0xFF55FF55, 0xFF3DDC97, 0xFF55AAFF, 0xFF7C6CFF, 0xFFB15CFF,
			0xFFFF77DD, 0xFFFF5555, 0xFFFFA040, 0xFFFFDD44, 0xFFFFFFFF
	};

	private final Screen parent;
	private Page page = lastPage;
	private int px, py, pw, ph;            // panel
	private int cx, cy, cw, ch;            // content viewport
	private double scroll = 0;
	private int contentHeight = 0;

	/** Clickable areas recorded while drawing. */
	private record Hit(int x1, int y1, int x2, int y2, Runnable click, Slider slider) {
		boolean contains(double mx, double my) {
			return mx >= x1 && mx < x2 && my >= y1 && my < y2;
		}
	}

	private record Slider(int x, int w, int min, int max, int step, IntConsumer set) {
		void setFromMouse(double mx) {
			double t = Math.max(0, Math.min(1, (mx - x) / (double) w));
			int raw = (int) Math.round(min + t * (max - min));
			int v = min + Math.round((raw - min) / (float) step) * step;
			set.accept(Math.max(min, Math.min(max, v)));
		}
	}

	private final List<Hit> hits = new ArrayList<>();
	private final List<Hit> pendingHits = new ArrayList<>();
	private Slider dragging = null;
	private String hint = null;
	private final Map<String, Float> anim = new HashMap<>();
	private int mouseX, mouseY;

	public MenuScreen(Screen parent) {
		super(Component.literal("Garden Tracker"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		pw = Math.min(430, width - 16);
		ph = Math.min(262, height - 16);
		px = (width - pw) / 2;
		py = (height - ph) / 2;
		cx = px + SIDEBAR_W + 12;
		cy = py + 38;
		cw = pw - SIDEBAR_W - 24;
		ch = ph - 38 - 22;
	}

	// ===================== drawing =====================

	@Override
	public void extractBackground(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
		// Our own dim instead of the vanilla blur, so the live HUD stays sharp behind the menu.
		g.fill(0, 0, width, height, 0x70000000);
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float a) {
		super.extractRenderState(g, mouseX, mouseY, a);
		this.mouseX = mouseX;
		this.mouseY = mouseY;
		pendingHits.clear();
		hint = null;
		int accent = Config.get().accent();

		// Panel + sidebar
		Ui.round(g, px - 1, py - 1, px + pw + 1, py + ph + 1, Ui.alpha(accent, 0x55));
		Ui.round(g, px, py, px + pw, py + ph, BG);
		g.fill(px + 2, py, px + SIDEBAR_W, py + ph, SIDEBAR);
		g.fill(px, py + 2, px + 2, py + ph - 2, SIDEBAR);

		// Logo
		g.fill(px + 10, py + 11, px + 13, py + 25, accent);
		g.text(font, "Garden", px + 17, py + 10, TEXT, false);
		g.text(font, "Tracker", px + 17, py + 19, accent, false);

		// Navigation
		int ny = py + 38;
		for (Page p : Page.values()) {
			boolean active = p == page;
			boolean hover = !active && inside(mouseX, mouseY, px + 4, ny, px + SIDEBAR_W - 4, ny + 18);
			float t = ease("nav" + p.ordinal(), active ? 1f : hover ? 0.5f : 0f);
			if (t > 0.01f) Ui.round(g, px + 4, ny, px + SIDEBAR_W - 4, ny + 18, Ui.alpha(accent, (int) (t * 0x30)));
			if (active) g.fill(px + 4, ny + 4, px + 6, ny + 14, accent);
			g.text(font, p.icon, px + 11, ny + 5, active ? accent : MUTED, false);
			g.text(font, p.title, px + 24, ny + 5, active ? TEXT : MUTED, false);
			final Page target = p;
			pendingHits.add(new Hit(px + 4, ny, px + SIDEBAR_W - 4, ny + 18, () -> switchPage(target), null));
			ny += 20;
		}
		g.text(font, "v3.0", px + 10, py + ph - 14, FAINT, false);

		// Header
		g.text(font, page.title, cx, py + 11, TEXT, false);
		g.text(font, page.subtitle, cx, py + 22, MUTED, false);
		int closeX = px + pw - 18;
		boolean closeHover = inside(mouseX, mouseY, closeX - 3, py + 7, closeX + 11, py + 21);
		if (closeHover) Ui.round(g, closeX - 3, py + 7, closeX + 11, py + 21, 0x40FF5555);
		g.text(font, "✕", closeX + 1, py + 10, closeHover ? 0xFFFF7777 : MUTED, false);
		pendingHits.add(new Hit(closeX - 3, py + 7, closeX + 11, py + 21, this::onClose, null));

		// Content (scrollable, clipped)
		g.enableScissor(cx - 2, cy, cx + cw + 2, cy + ch);
		int y = cy - (int) scroll;
		int start = y;
		switch (page) {
			case DASHBOARD -> y = dashboard(g, y);
			case APPEARANCE -> y = appearance(g, y);
			case LAYOUT -> y = layout(g, y);
			case TRACKING -> y = tracking(g, y);
			case PESTS -> y = pests(g, y);
			case ALERTS -> y = alerts(g, y);
			case VISITORS -> y = visitors(g, y);
			case HISTORY -> y = history(g, y);
		}
		g.disableScissor();
		contentHeight = y - start;

		// Scrollbar
		if (contentHeight > ch) {
			int barH = Math.max(16, ch * ch / contentHeight);
			int barY = cy + (int) ((ch - barH) * (scroll / (contentHeight - ch)));
			g.fill(px + pw - 5, cy, px + pw - 3, cy + ch, 0x30FFFFFF);
			g.fill(px + pw - 5, barY, px + pw - 3, barY + barH, Ui.alpha(accent, 0xB0));
		}

		// Footer hint
		g.fill(cx, py + ph - 19, cx + cw, py + ph - 18, 0x20FFFFFF);
		String footer = hint != null ? hint : "Esc to close  ·  scroll for more  ·  /gt edit to move the HUD";
		g.text(font, footer, cx, py + ph - 13, hint != null ? TEXT : FAINT, false);

		hits.clear();
		hits.addAll(pendingHits);
	}

	// ===================== pages =====================

	private int dashboard(GuiGraphicsExtractor g, int y) {
		Config c = Config.get();
		int gap = 6;
		int w = (cw - gap * 2) / 3;
		statCard(g, cx, y, w, "Coins / hr", Text.num(Session.coinsPerHour()), 0xFFFFAA00, "best " + Text.num(c.bestCoinsPerHour));
		statCard(g, cx + w + gap, y, w, "Cultivating / hr", Text.num(Session.cultivatingPerHour()), 0xFF55FFFF, "best " + Text.num(c.bestCultivatingPerHour));
		statCard(g, cx + (w + gap) * 2, y, w, "Farming XP / hr", Text.num(Session.xpPerHour()), 0xFFFF77FF, "best " + Text.num(c.bestXpPerHour));
		y += 44;

		// Chart card
		card(g, cx, y, cx + cw, y + 50, false);
		g.text(font, "Coins / hr  ·  last 10 minutes", cx + 8, y + 6, MUTED, false);
		g.text(font, "now " + Text.num(Chart.liveRate()), cx + cw - 8 - font.width("now " + Text.num(Chart.liveRate())), y + 6, TEXT, false);
		drawChart(g, cx + 8, y + 18, cw - 16, 26, c.accent());
		y += 56;

		// Session card
		card(g, cx, y, cx + cw, y + 34, false);
		g.text(font, "Session", cx + 8, y + 6, MUTED, false);
		String state = Session.isActive() && Session.hasData() ? "§afarming" : "§7paused";
		g.text(font, state, cx + cw - 8 - font.width(Text.stripColor(state)), y + 6, TEXT, false);
		g.text(font, Text.time(Session.activeSeconds) + "   §6" + Text.commas(Math.round(Session.coins)) + " coins   §b"
				+ Text.commas(Session.cultivating) + " crops   §d" + Text.commas(Math.round(Session.xp)) + " XP", cx + 8, y + 19, TEXT, false);
		y += 40;

		int bw = (cw - gap * 2) / 3;
		button(g, cx, y, bw, "Reset session", true, () -> GardenTracker.resetSession(), "Saves this Garden visit to History, then starts fresh");
		button(g, cx + bw + gap, y, bw, "Move HUD", false, () -> minecraft.setScreen(new HudEditorScreen(this)), "Drag the HUD and scroll to resize it");
		button(g, cx + (bw + gap) * 2, y, bw, "Summary to chat", false, () -> {
			onClose();
			GardenTracker.printSummary(minecraft, "Session summary:");
		}, "Posts the full session breakdown in chat");
		return y + 26;
	}

	private int appearance(GuiGraphicsExtractor g, int y) {
		Config c = Config.get();
		y = section(g, y, "Style");
		y = choice(g, y, "Theme", "Background, text and border colors",
				() -> c.theme.ordinal(), i -> c.theme = Theme.values()[i], Theme.values().length, i -> Theme.values()[i].displayName);
		y = swatches(g, y, "Accent color", "Title, chart, border and menu color. First swatch = theme color",
				() -> c.accentColor, v -> c.accentColor = v);
		y = slider(g, y, "Background opacity", "How see-through the HUD box is", 0, 100, 5, () -> c.backgroundOpacity, v -> c.backgroundOpacity = v, v -> v + "%");
		y = toggle(g, y, "Background", "Draw the box behind the HUD", () -> c.hudBackground, v -> c.hudBackground = v);
		y = toggle(g, y, "Border", "Thin outline around the HUD", () -> c.hudBorder, v -> c.hudBorder = v);
		y = toggle(g, y, "Text shadow", "Easier to read on bright backgrounds", () -> c.textShadow, v -> c.textShadow = v);

		y = section(g, y, "Size & text");
		y = slider(g, y, "Scale", "Size of the HUD", 50, 300, 5, () -> Math.round(c.hudScale * 100), v -> c.hudScale = v / 100f, v -> v + "%");
		y = slider(g, y, "Line spacing", "Extra space between lines", 0, 6, 1, () -> c.lineSpacing, v -> c.lineSpacing = v, v -> v + "px");
		y = toggle(g, y, "Title bar", "Show the \"Garden Tracker\" header", () -> c.showTitle, v -> c.showTitle = v);
		y = toggle(g, y, "Compact labels", "Short labels like $/h and XP/h", () -> c.compact, v -> c.compact = v);
		y = toggle(g, y, "Short numbers", "1.23M instead of 1,234,567", () -> c.shortNumbers, v -> c.shortNumbers = v);
		y = toggle(g, y, "Show HUD", "Turn the whole HUD on or off", () -> c.hudEnabled, v -> c.hudEnabled = v);
		y += 4;
		button(g, cx, y, cw, "Move & resize the HUD", true, () -> minecraft.setScreen(new HudEditorScreen(this)), "Drag to move, scroll to resize");
		return y + 26;
	}

	private int layout(GuiGraphicsExtractor g, int y) {
		Config c = Config.get();
		y = section(g, y, "HUD lines (top to bottom)");
		List<HudLine> order = c.orderedLines();
		for (int i = 0; i < order.size(); i++) {
			HudLine line = order.get(i);
			boolean hover = rowHover(y);
			card(g, cx, y, cx + cw, y + ROW_H - 2, hover);
			g.text(font, line.label, cx + 8, y + 7, c.isShown(line) ? TEXT : MUTED, false);
			// up / down
			int ax = cx + cw - 80;
			iconButton(g, ax, y + 4, "▲", i > 0, () -> c.moveLine(line, -1));
			iconButton(g, ax + 16, y + 4, "▼", i < order.size() - 1, () -> c.moveLine(line, 1));
			switchControl(g, cx + cw - 32, y + 6, "line" + line.name(), c.isShown(line), () -> c.setShown(line, !c.isShown(line)));
			y += ROW_H;
		}
		return y;
	}

	private int tracking(GuiGraphicsExtractor g, int y) {
		Config c = Config.get();
		y = section(g, y, "Prices");
		y = choice(g, y, "Crop prices", "Best = higher of NPC and Bazaar instant-sell",
				() -> c.priceMode.ordinal(), i -> c.priceMode = Config.PriceMode.values()[i], 3, i -> Config.PriceMode.values()[i].name().toLowerCase());
		y = section(g, y, "Goal");
		y = choice(g, y, "Goal", "Shown on the HUD with an ETA",
				() -> c.goalType.ordinal(), i -> c.goalType = Config.GoalType.values()[i], 4, i -> Config.GoalType.values()[i].name().toLowerCase());
		y = slider(g, y, "Coin goal", "Used when Goal is set to coins", 1, 500, 1,
				() -> (int) Math.min(500, c.goalCoins / 1_000_000L), v -> c.goalCoins = v * 1_000_000L, v -> v + "M");
		y = section(g, y, "Session");
		y = slider(g, y, "Pause timer after", "Seconds without farming before the timer pauses", 3, 60, 1,
				() -> c.pauseSeconds, v -> c.pauseSeconds = v, v -> v + "s");
		return y;
	}

	private int pests(GuiGraphicsExtractor g, int y) {
		Config c = Config.get();
		y = section(g, y, "Highlight infested plots");
		y = toggle(g, y, "Plot highlight", "Outline plots with pests in the world", () -> c.plotHighlight, v -> c.plotHighlight = v);
		y = toggle(g, y, "Through walls", "See the outline through blocks", () -> c.plotHighlightThroughWalls, v -> c.plotHighlightThroughWalls = v);
		y = toggle(g, y, "Labels", "Floating \"Plot 4 - 3 pests\" text", () -> c.plotHighlightLabels, v -> c.plotHighlightLabels = v);
		y = toggle(g, y, "Floor tint", "Tint the ground of infested plots", () -> c.plotHighlightFill, v -> c.plotHighlightFill = v);
		y = slider(g, y, "Outline height", "Blocks above the lowest Garden point", 2, 36, 1, () -> c.plotHighlightHeight, v -> c.plotHighlightHeight = v, v -> v + " blocks");
		y = swatches(g, y, "Highlight color", "Color of outlines, labels and the plot map",
				() -> c.plotHighlightColor, v -> c.plotHighlightColor = v == 0 ? 0xFFFF5555 : v);

		y = section(g, y, "Plot map");
		y = toggle(g, y, "Plot map on HUD", "5×5 grid: red = pests, outlined = you", () -> c.isShown(HudLine.PLOT_MAP), v -> c.setShown(HudLine.PLOT_MAP, v));
		// Live map preview
		int mapH = 5 * 12 + 12;
		card(g, cx, y, cx + cw, y + mapH, false);
		int mx = cx + 10, my = y + 6;
		java.util.Map<Integer, Integer> infested = Plots.infested();
		int here = Plots.currentPlot();
		for (int row = 0; row < 5; row++) {
			for (int col = 0; col < 5; col++) {
				int id = Plots.LAYOUT[row][col];
				int x1 = mx + col * 12, y1 = my + row * 12;
				Integer n = infested.get(id);
				int fill = n != null ? (c.plotHighlightColor | 0xFF000000) : id == 0 ? 0xFF6B5A3A : 0xFF2C303A;
				Ui.round(g, x1, y1, x1 + 11, y1 + 11, fill);
				if (id == here) Ui.roundOutline(g, x1 - 1, y1 - 1, x1 + 12, y1 + 12, c.accent());
				String s = n != null ? (n < 0 ? "?" : String.valueOf(n)) : id == 0 ? "B" : "";
				if (!s.isEmpty()) g.text(font, s, x1 + 6 - font.width(s) / 2, y1 + 2, 0xFFFFFFFF, false);
			}
		}
		int tx = mx + 5 * 12 + 12;
		g.text(font, "Pests alive: §f" + (GardenInfo.pestsAlive < 0 ? "-" : GardenInfo.pestsAlive), tx, my, MUTED, false);
		int ly = my + 12;
		if (infested.isEmpty()) {
			g.text(font, "§aNo infested plots", tx, ly, TEXT, false);
		} else {
			for (Map.Entry<Integer, Integer> e : infested.entrySet()) {
				if (ly > my + 48) break;
				int n = e.getValue();
				g.text(font, "Plot " + Plots.name(e.getKey()) + "  §7" + (n < 0 ? "count unknown" : n + (n == 1 ? " pest" : " pests")), tx, ly, TEXT, false);
				ly += 10;
			}
		}
		y += mapH + 4;
		g.text(font, "§8Counts come from spawn messages and the Configure Plots menu (/desk).", cx, y, MUTED, false);
		y += 14;

		y = section(g, y, "Pest alert");
		y = toggle(g, y, "Pest alert", "Title + sound when pests reach the limit", () -> c.pestAlert, v -> c.pestAlert = v);
		y = slider(g, y, "Alert at", "Number of alive pests", 1, 8, 1, () -> c.pestAlertThreshold, v -> c.pestAlertThreshold = v, v -> v + " pests");
		return y;
	}

	private int alerts(GuiGraphicsExtractor g, int y) {
		Config c = Config.get();
		y = section(g, y, "Farming");
		y = slider(g, y, "Stopped-farming alert", "Ping if you hold your tool but stop farming (0 = off)", 0, 120, 5,
				() -> c.afkAlertSeconds, v -> c.afkAlertSeconds = v, v -> v == 0 ? "off" : v + "s");
		y = section(g, y, "Garden");
		y = toggle(g, y, "Visitor queue full", "Chat message when no more visitors can arrive", () -> c.visitorQueueAlert, v -> c.visitorQueueAlert = v);
		y = toggle(g, y, "Summary on leave", "Post your session summary when you leave the Garden", () -> c.summaryOnLeave, v -> c.summaryOnLeave = v);
		y = section(g, y, "Sound");
		y = toggle(g, y, "Alert sounds", "Play a ping with alert titles", () -> c.alertSounds, v -> c.alertSounds = v);
		return y;
	}

	private int visitors(GuiGraphicsExtractor g, int y) {
		Config c = Config.get();
		y = section(g, y, "Offer breakdown");
		y = toggle(g, y, "Offer breakdown", "Cost, rewards, copper and a verdict on Accept Offer", () -> c.visitorCostTooltip, v -> c.visitorCostTooltip = v);
		y = slider(g, y, "Good copper deal", "Max coins per copper you're happy to pay", 500, 20_000, 500,
				() -> c.coinsPerCopper, v -> c.coinsPerCopper = v, v -> Text.commas(v) + " / copper");
		y += 4;
		card(g, cx, y, cx + cw, y + 46, false);
		g.text(font, "Hover §fAccept Offer §8in a visitor's menu to see:", cx + 8, y + 6, MUTED, false);
		g.text(font, "§7cost (Bazaar instant-buy) · reward items · copper", cx + 8, y + 18, MUTED, false);
		g.text(font, "§a● profit  §a● good copper deal  §c● pricey", cx + 8, y + 30, MUTED, false);
		y += 52;
		button(g, cx, y, 110, "Reload prices", false, Prices::forceRefresh, "Download fresh Bazaar and NPC prices");
		return y + 26;
	}

	private int history(GuiGraphicsExtractor g, int y) {
		History.Data d = History.data();
		long totalCrops = 0;
		double totalCoins = 0;
		for (History.CropTotal t : d.lifetime.values()) {
			totalCrops += t.crops;
			totalCoins += t.coins;
		}
		int gap = 6;
		int w = (cw - gap * 2) / 3;
		statCard(g, cx, y, w, "Lifetime farming", Text.time(d.lifetimeSeconds), 0xFFFFFFFF, d.visits.size() + " visits saved");
		statCard(g, cx + w + gap, y, w, "Lifetime crops", Text.shortNum(totalCrops), 0xFF55FFFF, d.lifetime.size() + " crop types");
		statCard(g, cx + (w + gap) * 2, y, w, "Lifetime coins", Text.shortNum(totalCoins), 0xFFFFAA00, "estimated");
		y += 44;

		y = section(g, y, "Recent visits");
		if (d.visits.isEmpty()) {
			g.text(font, "Farm for at least a minute, then leave the Garden.", cx, y + 2, MUTED, false);
			y += 14;
		} else {
			SimpleDateFormat fmt = new SimpleDateFormat("MMM d · HH:mm");
			for (int i = 0; i < Math.min(15, d.visits.size()); i++) {
				History.Visit v = d.visits.get(i);
				card(g, cx, y, cx + cw, y + 20, rowHover(y));
				g.text(font, fmt.format(new Date(v.endedAt)), cx + 8, y + 6, MUTED, false);
				g.text(font, v.mainCrop, cx + 80, y + 6, TEXT, false);
				String right = Text.time(v.seconds) + "  §6" + Text.shortNum(v.coinsPerHour()) + "/hr  §b" + Text.shortNum(v.cultivating);
				g.text(font, right, cx + cw - 8 - font.width(Text.stripColor(right)), y + 6, TEXT, false);
				y += 22;
			}
		}
		y += 4;
		y = toggle(g, y, "Save history", "Keep visits and lifetime totals on disk", () -> Config.get().saveHistory, v -> Config.get().saveHistory = v);
		button(g, cx, y + 2, 110, "§cClear history", false, History::clear, "Deletes saved visits and lifetime totals");
		return y + 28;
	}

	// ===================== components =====================

	private int section(GuiGraphicsExtractor g, int y, String title) {
		g.text(font, title.toUpperCase(), cx, y + 4, Ui.alpha(Config.get().accent(), 0xE0), false);
		g.fill(cx + font.width(title.toUpperCase()) + 6, y + 8, cx + cw, y + 9, 0x20FFFFFF);
		return y + 16;
	}

	private void card(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, boolean hover) {
		Ui.round(g, x1, y1, x2, y2, hover ? CARD_HOVER : CARD);
	}

	private void statCard(GuiGraphicsExtractor g, int x, int y, int w, String label, String value, int color, String sub) {
		card(g, x, y, x + w, y + 38, false);
		g.fill(x, y + 4, x + 2, y + 34, color);
		g.text(font, label, x + 8, y + 5, MUTED, false);
		g.pose().pushMatrix();
		g.pose().translate(x + 8, y + 15);
		g.pose().scale(1.4f, 1.4f);
		g.text(font, value, 0, 0, color, false);
		g.pose().popMatrix();
		g.text(font, sub, x + w - 6 - font.width(sub), y + 27, FAINT, false);
	}

	private boolean rowHover(int y) {
		return inside(mouseX, mouseY, cx, y, cx + cw, y + ROW_H - 2) && inViewport(mouseY);
	}

	private int row(GuiGraphicsExtractor g, int y, String label, String desc) {
		boolean hover = rowHover(y);
		card(g, cx, y, cx + cw, y + ROW_H - 2, hover);
		g.text(font, label, cx + 8, y + 7, TEXT, false);
		if (hover) hint = desc;
		return y;
	}

	private int toggle(GuiGraphicsExtractor g, int y, String label, String desc, BooleanSupplier get, Consumer<Boolean> set) {
		row(g, y, label, desc);
		boolean on = get.getAsBoolean();
		Runnable flip = () -> set.accept(!get.getAsBoolean());
		switchControl(g, cx + cw - 32, y + 6, "t" + label, on, flip);
		addHit(cx, y, cx + cw, y + ROW_H - 2, flip, null); // whole row is clickable
		return y + ROW_H;
	}

	private void switchControl(GuiGraphicsExtractor g, int x, int y, String key, boolean on, Runnable flip) {
		float t = ease(key, on ? 1f : 0f);
		int accent = Config.get().accent();
		Ui.round(g, x, y, x + 22, y + 10, Ui.mix(TRACK, accent, t));
		int kx = x + 1 + Math.round(t * 12);
		Ui.round(g, kx, y + 1, kx + 9, y + 9, 0xFFFFFFFF);
		addHit(x - 2, y - 2, x + 24, y + 12, flip, null);
	}

	private int slider(GuiGraphicsExtractor g, int y, String label, String desc, int min, int max, int step,
					   IntSupplier get, IntConsumer set, IntFunction<String> fmt) {
		row(g, y, label, desc);
		int w = Math.min(110, cw / 3);
		int sx = cx + cw - w - 10;
		int sy = y + 10;
		int v = get.getAsInt();
		float t = (v - min) / (float) Math.max(1, max - min);
		int accent = Config.get().accent();
		g.fill(sx, sy, sx + w, sy + 2, TRACK);
		g.fill(sx, sy, sx + Math.round(w * t), sy + 2, accent);
		int kx = sx + Math.round(w * t);
		Ui.round(g, kx - 3, sy - 4, kx + 3, sy + 6, 0xFFFFFFFF);
		String text = fmt.apply(v);
		g.text(font, text, sx - 8 - font.width(text), y + 7, MUTED, false);
		addHit(sx - 4, y + 2, sx + w + 4, y + ROW_H - 4, null, new Slider(sx, w, min, max, step, val -> {
			set.accept(val);
		}));
		return y + ROW_H;
	}

	private int choice(GuiGraphicsExtractor g, int y, String label, String desc, IntSupplier get, IntConsumer set, int count, IntFunction<String> name) {
		row(g, y, label, desc);
		int i = get.getAsInt();
		String value = name.apply(i);
		int w = Math.max(80, font.width(value) + 30);
		int x2 = cx + cw - 8, x1 = x2 - w;
		Ui.round(g, x1, y + 4, x2, y + ROW_H - 6, 0xFF262A34);
		boolean hl = inside(mouseX, mouseY, x1, y + 4, x1 + 14, y + ROW_H - 6);
		boolean hr = inside(mouseX, mouseY, x2 - 14, y + 4, x2, y + ROW_H - 6);
		g.text(font, "‹", x1 + 5, y + 7, hl ? TEXT : MUTED, false);
		g.text(font, "›", x2 - 9, y + 7, hr ? TEXT : MUTED, false);
		g.text(font, value, x1 + (w - font.width(value)) / 2, y + 7, Config.get().accent(), false);
		addHit(x1, y + 4, x1 + w / 2, y + ROW_H - 6, () -> set.accept((get.getAsInt() - 1 + count) % count), null);
		addHit(x1 + w / 2, y + 4, x2, y + ROW_H - 6, () -> set.accept((get.getAsInt() + 1) % count), null);
		return y + ROW_H;
	}

	private int swatches(GuiGraphicsExtractor g, int y, String label, String desc, IntSupplier get, IntConsumer set) {
		row(g, y, label, desc);
		int size = 10, gap = 3;
		int total = SWATCHES.length * (size + gap) - gap;
		int sx = cx + cw - 8 - total;
		int current = get.getAsInt();
		for (int i = 0; i < SWATCHES.length; i++) {
			int color = SWATCHES[i];
			int x1 = sx + i * (size + gap), y1 = y + 6;
			int shown = color == 0 ? Config.get().theme.accent : color;
			Ui.round(g, x1, y1, x1 + size, y1 + size, shown);
			if (color == 0) g.text(font, "T", x1 + 3, y1 + 1, 0xFF000000, false);
			if (current == color) Ui.roundOutline(g, x1 - 2, y1 - 2, x1 + size + 2, y1 + size + 2, 0xFFFFFFFF);
			addHit(x1 - 1, y1 - 1, x1 + size + 1, y1 + size + 1, () -> set.accept(color), null);
		}
		return y + ROW_H;
	}

	private void button(GuiGraphicsExtractor g, int x, int y, int w, String label, boolean primary, Runnable action, String desc) {
		boolean hover = inside(mouseX, mouseY, x, y, x + w, y + 20) && inViewport(mouseY);
		int accent = Config.get().accent();
		int fill = primary ? (hover ? accent : Ui.alpha(accent, 0xC0)) : (hover ? 0xFF2E3340 : 0xFF262A34);
		Ui.round(g, x, y, x + w, y + 20, fill);
		int textColor = primary ? 0xFF101114 : TEXT;
		g.text(font, label, x + (w - font.width(Text.stripColor(label))) / 2, y + 6, textColor, false);
		if (hover) hint = desc;
		addHit(x, y, x + w, y + 20, action, null);
	}

	private void iconButton(GuiGraphicsExtractor g, int x, int y, String icon, boolean enabled, Runnable action) {
		boolean hover = enabled && inside(mouseX, mouseY, x, y, x + 14, y + 14);
		Ui.round(g, x, y, x + 14, y + 14, hover ? 0xFF343947 : 0xFF262A34);
		g.text(font, icon, x + 4, y + 3, enabled ? (hover ? TEXT : MUTED) : FAINT, false);
		if (enabled) addHit(x, y, x + 14, y + 14, action, null);
	}

	private void drawChart(GuiGraphicsExtractor g, int x, int y, int w, int h, int accent) {
		g.fill(x, y + h - 1, x + w, y + h, 0x30FFFFFF);
		int n = Chart.count();
		if (n == 0) {
			g.text(font, "Farm in the Garden to fill the chart", x + (w - font.width("Farm in the Garden to fill the chart")) / 2, y + h / 2 - 4, FAINT, false);
			return;
		}
		double max = Math.max(Chart.max(), 1);
		float barW = w / (float) Chart.BARS;
		for (int i = 0; i < n; i++) {
			int bh = (int) Math.round(Chart.bar(i) / max * (h - 2));
			if (bh <= 0) continue;
			int bx = x + w - Math.round((n - i) * barW);
			int color = Ui.mix(Ui.alpha(accent, 0x60), accent, (float) i / Math.max(1, n - 1));
			g.fill(bx, y + h - 1 - bh, bx + Math.max(1, Math.round(barW) - 1), y + h - 1, color);
		}
	}

	// ===================== input =====================

	private void addHit(int x1, int y1, int x2, int y2, Runnable click, Slider slider) {
		// Only content inside the scroll viewport (or the fixed chrome) is clickable.
		pendingHits.add(new Hit(x1, Math.max(y1, cy), x2, Math.min(y2, cy + ch), click, slider));
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
		if (click.button() != 0) return super.mouseClicked(click, doubled);
		// Last recorded hits win (controls are recorded after their rows).
		for (int i = hits.size() - 1; i >= 0; i--) {
			Hit h = hits.get(i);
			if (h.y2() <= h.y1() || !h.contains(click.x(), click.y())) continue;
			if (h.slider() != null) {
				dragging = h.slider();
				dragging.setFromMouse(click.x());
			} else if (h.click() != null) {
				h.click().run();
			}
			Config.save();
			return true;
		}
		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent click, double dx, double dy) {
		if (dragging != null) {
			dragging.setFromMouse(click.x());
			return true;
		}
		return super.mouseDragged(click, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent click) {
		if (dragging != null) {
			dragging = null;
			Config.save();
			return true;
		}
		return super.mouseReleased(click);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double h, double v) {
		scroll = Math.max(0, Math.min(Math.max(0, contentHeight - ch), scroll - v * 18));
		return true;
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		if (GardenTracker.menuKey().matches(event)) {
			onClose();
			return true;
		}
		return super.keyPressed(event);
	}

	private void switchPage(Page p) {
		page = p;
		lastPage = p;
		scroll = 0;
	}

	private boolean inViewport(int my) {
		return my >= cy && my < cy + ch;
	}

	private static boolean inside(double mx, double my, int x1, int y1, int x2, int y2) {
		return mx >= x1 && mx < x2 && my >= y1 && my < y2;
	}

	/** Smoothly moves a value toward target (for switch and hover animations). */
	private float ease(String key, float target) {
		float v = anim.getOrDefault(key, target);
		v += (target - v) * 0.35f;
		if (Math.abs(target - v) < 0.01f) v = target;
		anim.put(key, v);
		return v;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		Config.save();
		minecraft.setScreen(parent);
	}
}
