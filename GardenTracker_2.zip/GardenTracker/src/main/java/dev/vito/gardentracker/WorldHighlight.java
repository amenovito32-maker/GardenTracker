package dev.vito.gardentracker;

import com.mojang.blaze3d.pipeline.DepthStencilState;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.CompareOp;
import com.mojang.blaze3d.vertex.ByteBufferBuilder;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.client.renderer.rendertype.LayeringTransform;
import net.minecraft.client.renderer.rendertype.OutputTarget;
import net.minecraft.client.renderer.rendertype.RenderSetup;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.Map;

import static net.minecraft.util.LightCoordsUtil.FULL_BRIGHT;

/**
 * Draws an outline around Garden plots that have pests, with a floating "Plot 4 - 3 pests" label.
 * Display only. The drawing technique (render pipelines, line vertices, see-through text) is the one NoFrills uses on 26.1.
 */
public final class WorldHighlight {
	private static final MultiBufferSource.BufferSource BUFFERS = MultiBufferSource.immediate(new ByteBufferBuilder(2048));

	private static final RenderPipeline LINES_SEE_THROUGH_PIPELINE = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.LINES_SNIPPET)
					.withDepthStencilState(new DepthStencilState(CompareOp.NOT_EQUAL, false))
					.withLocation("pipeline/gardentracker_lines_see_through")
					.build()
	);
	private static final RenderPipeline FILLED_SEE_THROUGH_PIPELINE = RenderPipelines.register(
			RenderPipeline.builder(RenderPipelines.DEBUG_FILLED_SNIPPET)
					.withLocation("pipeline/gardentracker_filled_see_through")
					.withDepthStencilState(new DepthStencilState(CompareOp.NOT_EQUAL, false))
					.build()
	);
	private static final RenderType LINES_SEE_THROUGH = RenderType.create(
			"gardentracker_lines_see_through",
			RenderSetup.builder(LINES_SEE_THROUGH_PIPELINE)
					.setLayeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
					.setOutputTarget(OutputTarget.ITEM_ENTITY_TARGET)
					.createRenderSetup()
	);
	private static final RenderType FILLED_SEE_THROUGH = RenderType.create(
			"gardentracker_filled_see_through",
			RenderSetup.builder(FILLED_SEE_THROUGH_PIPELINE)
					.sortOnUpload()
					.setLayeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
					.createRenderSetup()
	);

	private WorldHighlight() {}

	public static void render(CameraRenderState camera) {
		Config c = Config.get();
		if (!c.plotHighlight || !GardenInfo.inGarden) return;
		Map<Integer, Integer> infested = Plots.infested();
		if (infested.isEmpty()) return;

		PoseStack pose = new PoseStack();
		Vec3 cam = camera.pos;
		boolean through = c.plotHighlightThroughWalls;
		int color = c.plotHighlightColor;
		int fill = (color & 0x00FFFFFF) | (0x30 << 24);

		for (Map.Entry<Integer, Integer> e : infested.entrySet()) {
			int id = e.getKey();
			double x1 = Plots.minX(id), z1 = Plots.minZ(id);
			double x2 = x1 + Plots.SIZE, z2 = z1 + Plots.SIZE;
			double y1 = Plots.MIN_Y, y2 = Plots.MIN_Y + c.plotHighlightHeight;

			VertexConsumer lines = BUFFERS.getBuffer(through ? LINES_SEE_THROUGH : RenderTypes.lines());
			box(pose, lines, cam, x1, y1, z1, x2, y2, z2, color, 3.0f);
			if (c.plotHighlightFill) {
				VertexConsumer quads = BUFFERS.getBuffer(through ? FILLED_SEE_THROUGH : RenderTypes.debugFilledBox());
				// Only a floor tint so it doesn't block your view.
				quad(pose, quads, cam, x1, y1 + 0.05, z1, x2, y1 + 0.05, z1, x2, y1 + 0.05, z2, x1, y1 + 0.05, z2, fill);
			}

			if (c.plotHighlightLabels) {
				int n = e.getValue();
				String count = n < 0 ? "pests" : n + (n == 1 ? " pest" : " pests");
				String label = "Plot " + Plots.name(id) + " - " + count;
				text(camera, new Vec3(x1 + Plots.SIZE / 2.0, y2 + 2, z1 + Plots.SIZE / 2.0), Component.literal(label), color | 0xFF000000);
			}
		}
		BUFFERS.endBatch();
	}

	// ----- drawing helpers (adapted from NoFrills' WorldRenderEvent) -----

	private static void line(PoseStack pose, VertexConsumer c, Vec3 cam, double ax, double ay, double az, double bx, double by, double bz, int color, float width) {
		PoseStack.Pose p = pose.last();
		float x1 = (float) (ax - cam.x()), y1 = (float) (ay - cam.y()), z1 = (float) (az - cam.z());
		float x2 = (float) (bx - cam.x()), y2 = (float) (by - cam.y()), z2 = (float) (bz - cam.z());
		c.addVertex(p, x1, y1, z1).setNormal(p, x2 - x1, y2 - y1, z2 - z1).setColor(color).setLineWidth(width);
		c.addVertex(p, x2, y2, z2).setNormal(p, x2 - x1, y2 - y1, z2 - z1).setColor(color).setLineWidth(width);
	}

	private static void box(PoseStack pose, VertexConsumer c, Vec3 cam, double x1, double y1, double z1, double x2, double y2, double z2, int color, float w) {
		// bottom
		line(pose, c, cam, x1, y1, z1, x2, y1, z1, color, w);
		line(pose, c, cam, x2, y1, z1, x2, y1, z2, color, w);
		line(pose, c, cam, x2, y1, z2, x1, y1, z2, color, w);
		line(pose, c, cam, x1, y1, z2, x1, y1, z1, color, w);
		// top
		line(pose, c, cam, x1, y2, z1, x2, y2, z1, color, w);
		line(pose, c, cam, x2, y2, z1, x2, y2, z2, color, w);
		line(pose, c, cam, x2, y2, z2, x1, y2, z2, color, w);
		line(pose, c, cam, x1, y2, z2, x1, y2, z1, color, w);
		// corners
		line(pose, c, cam, x1, y1, z1, x1, y2, z1, color, w);
		line(pose, c, cam, x2, y1, z1, x2, y2, z1, color, w);
		line(pose, c, cam, x2, y1, z2, x2, y2, z2, color, w);
		line(pose, c, cam, x1, y1, z2, x1, y2, z2, color, w);
	}

	private static void quad(PoseStack pose, VertexConsumer c, Vec3 cam,
							 double ax, double ay, double az, double bx, double by, double bz,
							 double cx, double cy, double cz, double dx, double dy, double dz, int color) {
		PoseStack.Pose p = pose.last();
		c.addVertex(p, (float) (ax - cam.x()), (float) (ay - cam.y()), (float) (az - cam.z())).setColor(color);
		c.addVertex(p, (float) (bx - cam.x()), (float) (by - cam.y()), (float) (bz - cam.z())).setColor(color);
		c.addVertex(p, (float) (cx - cam.x()), (float) (cy - cam.y()), (float) (cz - cam.z())).setColor(color);
		c.addVertex(p, (float) (dx - cam.x()), (float) (dy - cam.y()), (float) (dz - cam.z())).setColor(color);
	}

	private static void text(CameraRenderState camera, Vec3 pos, Component text, int color) {
		Font font = Minecraft.getInstance().font;
		Vec3 cam = camera.pos;
		double dist = cam.distanceTo(pos);
		float scale = (float) Math.max(0.025, 0.025 * (1 + dist * 0.1));
		Matrix4f m = new Matrix4f();
		m.translate((float) (pos.x() - cam.x()), (float) (pos.y() - cam.y()), (float) (pos.z() - cam.z()));
		m.rotate(camera.orientation);
		m.scale(scale, -scale, scale);
		font.drawInBatch(text, -font.width(text) / 2f, 0f, color, true, m, BUFFERS, Font.DisplayMode.SEE_THROUGH, 0x40000000, FULL_BRIGHT);
	}
}
