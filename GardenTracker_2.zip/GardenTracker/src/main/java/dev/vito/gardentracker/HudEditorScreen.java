package dev.vito.gardentracker;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

/** Drag the HUD with the left mouse button, scroll to resize it. */
public final class HudEditorScreen extends Screen {
	private final Screen parent;
	private boolean dragging = false;
	private double offsetX, offsetY;

	public HudEditorScreen(Screen parent) {
		super(Component.literal("Garden Tracker - HUD editor"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int y = height - 26;
		addRenderableWidget(Button.builder(Component.literal("Reset"), b -> {
			Config c = Config.get();
			c.hudX = 4;
			c.hudY = 40;
			c.hudScale = 1.0f;
			Config.save();
		}).bounds(width / 2 - 104, y, 100, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
				.bounds(width / 2 + 4, y, 100, 20).build());
	}

	private int boxW() {
		return Math.round(Hud.lastWidth * Config.get().hudScale);
	}

	private int boxH() {
		return Math.round(Hud.lastHeight * Config.get().hudScale);
	}

	private boolean overHud(double mx, double my) {
		Config c = Config.get();
		return mx >= c.hudX && mx <= c.hudX + boxW() && my >= c.hudY && my <= c.hudY + boxH();
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
		super.extractRenderState(graphics, mouseX, mouseY, a);
		Config c = Config.get();
		Hud.draw(graphics, c.hudX, c.hudY, c.hudScale);

		// Outline the box so you can see what you're dragging.
		int color = overHud(mouseX, mouseY) || dragging ? c.accent() | 0xFF000000 : 0x90FFFFFF;
		int x1 = c.hudX - 1, y1 = c.hudY - 1, x2 = c.hudX + boxW() + 1, y2 = c.hudY + boxH() + 1;
		graphics.fill(x1, y1, x2, y1 + 1, color);
		graphics.fill(x1, y2 - 1, x2, y2, color);
		graphics.fill(x1, y1, x1 + 1, y2, color);
		graphics.fill(x2 - 1, y1, x2, y2, color);

		String help = "Drag to move  ·  Scroll to resize  ·  " + Math.round(c.hudScale * 100) + "%";
		int hw = font.width(help) + 16;
		int hx = (width - hw) / 2, hy = height - 46;
		Ui.round(graphics, hx, hy, hx + hw, hy + 16, 0xE0101114);
		Ui.roundOutline(graphics, hx, hy, hx + hw, hy + 16, Ui.alpha(c.accent(), 0xA0));
		graphics.text(font, help, hx + 8, hy + 4, 0xFFE8EAF0, false);
	}

	@Override
	public boolean mouseClicked(MouseButtonEvent click, boolean doubled) {
		if (super.mouseClicked(click, doubled)) return true;
		if (click.button() == 0 && overHud(click.x(), click.y())) {
			dragging = true;
			offsetX = click.x() - Config.get().hudX;
			offsetY = click.y() - Config.get().hudY;
			return true;
		}
		return false;
	}

	@Override
	public boolean mouseDragged(MouseButtonEvent click, double dx, double dy) {
		if (dragging) {
			Config c = Config.get();
			c.hudX = (int) Math.max(0, Math.min(width - boxW(), click.x() - offsetX));
			c.hudY = (int) Math.max(0, Math.min(height - boxH(), click.y() - offsetY));
			return true;
		}
		return super.mouseDragged(click, dx, dy);
	}

	@Override
	public boolean mouseReleased(MouseButtonEvent click) {
		if (dragging) {
			dragging = false;
			Config.save();
			return true;
		}
		return super.mouseReleased(click);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
		Config c = Config.get();
		float scale = c.hudScale + (vertical > 0 ? 0.1f : -0.1f);
		c.hudScale = Math.round(Math.max(0.5f, Math.min(3.0f, scale)) * 10f) / 10f;
		Config.save();
		return true;
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		Config.save();
		minecraft.setScreen(parent);
	}
}
