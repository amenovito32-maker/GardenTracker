package dev.vito.gardentracker;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Draws the Garden Tracker box. Shown only in the Garden (and as a preview in the editor and menu). */
public final class Hud {
	private static final int PAD = 5;
	private static final int GAP = 8;          // space between label and value columns
	private static final int CHART_HEIGHT = 18;
	private static final int MAP_CELL = 10;

	/** Size of the last drawn box in unscaled pixels, used by the HUD editor for dragging. */
	public static int lastWidth = 100;
	public static int lastHeight = 60;

	private record Row(HudLine line, String label, String value) {}

	private Hud() {}

	/** Fabric HUD callback. */
	public static void render(GuiGraphicsExtractor graphics, DeltaTracker delta) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.screen instanceof HudEditorScreen) return; // the editor draws its own preview
		boolean preview = mc.screen instanceof MenuScreen; // live preview behind the menu, even outside the Garden
		if (!Config.get().hudEnabled || (!GardenInfo.inGarden && !preview) || mc.player == null) return;
		draw(graphics, Config.get().hudX, Config.get().hudY, Config.get().hudScale);
	}

	/** Draws the HUD with its top-left corner at x, y. */
	public static void draw(GuiGraphicsExtractor graphics, int x, int y, float scale) {
		Config c = Config.get();
		Theme theme = c.theme;
		Font font = Minecraft.getInstance().font;
		int lineH = font.lineHeight + c.lineSpacing;
		int accent = c.accent();
		boolean shadow = c.textShadow;

		String status = Session.isActive() && Session.hasData() ? "§a●" : "§7○";
		String title = (c.compact || !c.showTitle) ? null : "Garden Tracker";
		List<Row> rows = buildRows(c);

		int labelW = 0, valueW = 0;
		for (Row r : rows) {
			if (isGraphic(r.line)) continue;
			labelW = Math.max(labelW, font.width(r.label));
			valueW = Math.max(valueW, font.width(r.value));
		}
		int width = labelW + GAP + valueW;
		if (title != null) width = Math.max(width, font.width(title) + 14);
		for (Row r : rows) if (r.line == HudLine.PLOT_MAP) width = Math.max(width, 5 * MAP_CELL + 64);
		width = Math.max(width, 80);

		int height = title == null ? 0 : lineH + 4;
		for (Row r : rows) {
			if (r.line == HudLine.CHART) height += CHART_HEIGHT + 3;
			else if (r.line == HudLine.PLOT_MAP) height += 5 * MAP_CELL + 4;
			else height += lineH;
		}
		lastWidth = width + PAD * 2;
		lastHeight = height + PAD * 2 - c.lineSpacing;

		graphics.pose().pushMatrix();
		graphics.pose().translate(x, y);
		graphics.pose().scale(scale, scale);

		if (c.hudBackground) {
			int bg = Ui.alpha(theme.background, Math.round(c.backgroundOpacity * 2.55f));
			if ((bg >>> 24) != 0) Ui.round(graphics, 0, 0, lastWidth, lastHeight, bg);
			if (c.hudBorder) {
				int border = (theme.border >>> 24) != 0 ? theme.border : Ui.alpha(accent, 0x90);
				Ui.roundOutline(graphics, 0, 0, lastWidth, lastHeight, border);
			}
		}

		int cy = PAD;
		if (title != null) {
			graphics.fill(PAD, cy, PAD + 2, cy + font.lineHeight - 1, accent);    // accent tick
			graphics.text(font, title, PAD + 5, cy, accent, shadow);
			graphics.text(font, status, lastWidth - PAD - font.width("●"), cy, 0xFFFFFFFF, shadow);
			cy += lineH + 1;
			graphics.fill(PAD, cy, lastWidth - PAD, cy + 1, Ui.alpha(accent, 0x50));  // divider
			cy += 3;
		}
		for (Row r : rows) {
			if (r.line == HudLine.CHART) {
				drawChart(graphics, PAD, cy, width, CHART_HEIGHT, accent);
				cy += CHART_HEIGHT + 3;
				continue;
			}
			if (r.line == HudLine.PLOT_MAP) {
				drawPlotMap(graphics, font, PAD, cy + 1, accent);
				cy += 5 * MAP_CELL + 4;
				continue;
			}
			graphics.text(font, r.label, PAD, cy, theme.labelColor, shadow);
			graphics.text(font, r.value, PAD + labelW + GAP, cy, theme.valueColor, shadow);
			cy += lineH;
		}
		graphics.pose().popMatrix();
	}

	private static boolean isGraphic(HudLine line) {
		return line == HudLine.CHART || line == HudLine.PLOT_MAP;
	}

	private static void drawChart(GuiGraphicsExtractor graphics, int x, int y, int w, int h, int accent) {
		graphics.fill(x, y, x + w, y + h, 0x30000000);
		graphics.fill(x, y + h - 1, x + w, y + h, Ui.alpha(accent, 0x60));
		int n = Chart.count();
		if (n == 0) return;
		double max = Math.max(Chart.max(), 1);
		int barW = Math.max(1, w / Chart.BARS);
		int startX = x + w - n * barW; // newest bar on the right
		for (int i = 0; i < n; i++) {
			int bh = (int) Math.round(Chart.bar(i) / max * (h - 2));
			if (bh <= 0) continue;
			int bx = startX + i * barW;
			int color = Ui.mix(Ui.alpha(accent, 0x70), accent, (float) i / Math.max(1, n - 1)); // older bars fade
			graphics.fill(bx, y + h - 1 - bh, bx + Math.max(1, barW - (barW > 2 ? 1 : 0)), y + h - 1, color);
		}
	}

	/** 5x5 plot grid: red = pests (with count), outlined = where you stand. */
	private static void drawPlotMap(GuiGraphicsExtractor graphics, Font font, int x, int y, int accent) {
		Map<Integer, Integer> infested = Plots.infested();
		int here = Plots.currentPlot();
		int pestColor = Config.get().plotHighlightColor | 0xFF000000;
		for (int row = 0; row < 5; row++) {
			for (int col = 0; col < 5; col++) {
				int id = Plots.LAYOUT[row][col];
				int x1 = x + col * MAP_CELL, y1 = y + row * MAP_CELL;
				int x2 = x1 + MAP_CELL - 1, y2 = y1 + MAP_CELL - 1;
				int fill = id == 0 ? 0x80806040 : 0x50FFFFFF;
				Integer pests = infested.get(id);
				if (pests != null) fill = Ui.alpha(pestColor, 0xD0);
				graphics.fill(x1, y1, x2, y2, fill);
				if (id == here) {
					graphics.fill(x1 - 1, y1 - 1, x2 + 1, y1, accent);
					graphics.fill(x1 - 1, y2, x2 + 1, y2 + 1, accent);
					graphics.fill(x1 - 1, y1, x1, y2, accent);
					graphics.fill(x2, y1, x2 + 1, y2, accent);
				}
				if (pests != null) {
					String s = pests < 0 ? "?" : pests > 9 ? "+" : String.valueOf(pests);
					graphics.text(font, s, x1 + (MAP_CELL - 1 - font.width(s)) / 2 + 1, y1 + 1, 0xFFFFFFFF, true);
				}
			}
		}
		// Legend to the right of the grid
		int lx = x + 5 * MAP_CELL + 6;
		if (!infested.isEmpty()) {
			int ly = y;
			int shown = 0;
			for (Map.Entry<Integer, Integer> e : infested.entrySet()) {
				if (shown++ == 4) break;
				int n = e.getValue();
				graphics.text(font, "§7" + Plots.name(e.getKey()) + " §f" + (n < 0 ? "?" : n), lx, ly, 0xFFFFFFFF, true);
				ly += font.lineHeight + 1;
			}
		} else {
			graphics.text(font, "§aNo pests", lx, y, 0xFFFFFFFF, true);
		}
	}

	private static List<Row> buildRows(Config c) {
		List<Row> rows = new ArrayList<>();
		for (HudLine line : c.orderedLines()) {
			if (!c.isShown(line)) continue;
			String value = value(line, c);
			if (value == null) continue;
			rows.add(new Row(line, c.compact ? line.shortLabel : line.label, value));
		}
		return rows;
	}

	/** The text for one HUD line, or null to hide it right now. */
	private static String value(HudLine line, Config c) {
		switch (line) {
			case CROP -> {
				Crop crop = Session.currentCrop;
				if (crop == null) return "§8hold a farming tool";
				return crop.displayName + " §8" + Text.num(crop.price(c.priceMode)) + " ea";
			}
			case COINS -> {
				return "§6" + Text.num(Session.coinsPerHour()) + best(Session.coinsPerHour(), c.bestCoinsPerHour);
			}
			case CULTIVATING -> {
				return "§b" + Text.num(Session.cultivatingPerHour()) + best(Session.cultivatingPerHour(), c.bestCultivatingPerHour);
			}
			case XP -> {
				return "§d" + Text.num(Session.xpPerHour()) + best(Session.xpPerHour(), c.bestXpPerHour);
			}
			case LIVE_RATE -> {
				return "§6" + Text.num(Chart.liveRate()) + " §8/hr";
			}
			case SESSION -> {
				return Text.time(Session.activeSeconds) + " §8· §6" + Text.num(Session.coins);
			}
			case CHART, PLOT_MAP -> {
				return "";
			}
			case PESTS -> {
				if (GardenInfo.pestsAlive < 0) return null;
				String color = GardenInfo.pestsAlive >= c.pestAlertThreshold && c.pestAlertThreshold > 0 ? "§c" : GardenInfo.pestsAlive > 0 ? "§e" : "§a";
				StringBuilder plots = new StringBuilder();
				if (GardenInfo.pestsAlive > 0 && !Plots.infested().isEmpty()) {
					plots.append(" §8(");
					int i = 0;
					for (Map.Entry<Integer, Integer> e : Plots.infested().entrySet()) {
						if (i++ > 0) plots.append(", ");
						plots.append(Plots.name(e.getKey()));
						if (e.getValue() > 0) plots.append("§7×").append(e.getValue()).append("§8");
					}
					plots.append(")");
				}
				return color + GardenInfo.pestsAlive + plots;
			}
			case PEST_COOLDOWN -> {
				if (GardenInfo.pestCooldown.isEmpty()) return null;
				String upper = GardenInfo.pestCooldown.toUpperCase(Locale.ROOT);
				if (upper.contains("READY")) return "§aready";
				if (upper.contains("MAX")) return "§cmax pests";
				return "§f" + GardenInfo.pestCooldown;
			}
			case VISITORS -> {
				if (GardenInfo.visitors < 0 && GardenInfo.nextVisitor.isEmpty()) return null;
				String count = GardenInfo.visitors >= 0 ? String.valueOf(GardenInfo.visitors) : "?";
				String next = GardenInfo.nextVisitor.isEmpty() ? "" : " §8· §f" + GardenInfo.nextVisitor;
				return count + next;
			}
			case GOAL -> {
				return Goals.value(c);
			}
		}
		return null;
	}

	private static String best(double now, double best) {
		if (best <= 0) return "";
		return now >= best && now > 0 ? " §a★" : " §8(" + Text.num(best) + ")";
	}
}
