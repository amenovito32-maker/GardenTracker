# Garden Tracker 3.0 (Fabric, Minecraft 26.1.2)

A Hypixel SkyBlock Garden helper that **only displays information**. It reads the tab list, the action bar, your held tool and item tooltips, and downloads public Hypixel price data. It never clicks, moves, farms or sends anything to the server for you.

Requires: **Fabric Loader** and **Fabric API** only.

## Opening the menu
Press **O** (change it in Options → Controls → Garden Tracker) or type **/gt**.

| Tab | What's there |
|---|---|
| Stats | Live coins, Cultivating and XP rates, session totals, personal records, price mode, goal, reset |
| HUD | On/off, background, **theme** (Classic, Midnight, Forest, Sunset, Candy, Minimal), compact mode, scale, **Move & resize HUD** |
| Lines | Turn every HUD line on or off |
| Alerts | Pest alert and threshold, stopped-farming alert, visitor-queue alert, sounds, summary on leave |
| Visitors | Offer breakdown tooltip and your coins-per-copper limit |
| History | Lifetime totals, per-crop totals and your last Garden visits |

**HUD editor** (`/gt edit` or HUD tab): drag the box with the mouse, scroll to resize it.

## HUD lines
Crop · Coins/hr · Cultivating/hr · Farming XP/hr · Last 60s rate · Session · **Coins chart** (last 10 minutes, one bar per 10 s) · Pests (with plots) · **Pest spawn cooldown** · Visitors · Goal with ETA.

## New in 3.0
- **Redesigned menu:** sidebar navigation, cards, animated switches, sliders, color swatches, scrolling pages, a dashboard with big stat cards and a chart. The live HUD stays visible behind the menu as a preview.
- **More customization:** accent color, background opacity, border, text shadow, title bar, line spacing, short/full numbers, and reordering HUD lines (Layout page).
- **Pest plot highlight:** infested plots are outlined in the world (optionally through walls) with a floating "Plot 4 - 3 pests" label. You can set the color, outline height, labels and floor tint.
- **Plot map:** a 5x5 grid on the HUD and the Pests page. Red means pests (with the count), and your current plot is outlined.
- **Pests per plot:** counts come from spawn messages, the Configure Plots menu (/desk) and the tab list. A "?" means a plot has pests but the exact count is unknown.

## Add-ons in 2.0
- **Charts & history:** live coin-rate chart, saved Garden visits (`/gt history`), lifetime totals per crop (`config/gardentracker-history.json`).
- **Pest timer:** pest spawn cooldown from the tab list.
- **Stopped-farming alert:** a title and sound if you're holding your tool but haven't farmed for N seconds (default 15; 0 = off).
- **Visitor offer breakdown:** cost of requested items, value of reward items, copper and coins per copper, and a verdict (profit / good copper deal / pricey).
- **Themes, compact mode, line toggles, drag-to-move HUD.**

## Commands
`/gt` menu · `/gt edit` HUD editor · `/gt stats` or `/gardenstats` summary · `/gt history` · `/gt reset` · `/gt toggle` · `/gt price best|npc|bazaar` · `/gt goal none|cultivating|level|coins <amount>` · `/gt pos <x> <y>` · `/gt scale <0.5-3>` · `/gt refresh`

## Known limits
- Coins are an estimate: main crop only (NPC or raw Bazaar price). Rare drops, pest loot and enchanted crafting aren't included.
- Sunflower and Moonflower share a hoe, so they're tracked together.
- Level ETA needs the action bar to show XP as numbers (`1,234/50,000`).
- Tab-list and tooltip text formats come from SkyHanni and NoFrills source code. If Hypixel changes them, that line or tooltip section just won't appear.
- Visitor reward items are valued only if the Bazaar lists them under the same name.

## Building
Upload `GardenTracker-source.zip` to the GitHub repo; `.github/workflows/build.yml` unpacks it, builds with Gradle 9.5.1 and Java 25, and checks that the jar contains the mod code and `fabric.mod.json`.
Versions: Minecraft 26.1.2, Fabric Loader 0.19.1, Loom 1.16.3, Fabric API 0.145.3+26.1.1.
